/*
 * Copyright 2010, 2011 Michael Ossmann
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */


#include <afh_est.h>
#include "SHM.h"
#include "SHM2.h"

//#define MIN1 (X) ((X) * (X+1))
#define MAX(a,b) ((a) * (b))
#define MAXU(a,b) ((a) * (b))

#define	NETWORK_SETTING_MACRO \
	struct _network_dat net_dat;\
	ssize_t recsize, buf_size = sizeof (struct _network_dat);\
	int  sock = socket (PF_INET, SOCK_DGRAM, IPPROTO_UDP);\
	struct sockaddr_in sa; \
	socklen_t fromlen	= sizeof(sa);\
	memset(&sa, 0, sizeof sa);\
	sa.sin_family 		= AF_INET;\
	sa.sin_addr.s_addr 	= htonl(INADDR_ANY);\
	sa.sin_port 		= htons(7654);\
 	if (-1 == bind ( sock, (struct sockaddr *) &sa, sizeof(sa)))\
	{ perror("error bind failed"); 	close(sock);	exit(EXIT_FAILURE); }


#define	RECV_NET_DAT \
	recsize = recvfrom(sock, (void *) &net_dat, buf_size, MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);\
	if ( 0 < recsize ){\
	curr_seq = net_dat.seq;\
	if ( 0 == fseq_n) fseq_n = curr_seq;}

#define PRINT_RESLT_AND_STOP \
	if ( 1 == stop_ubertooth ){\
	lseq_n  = curr_seq;\
	printf ("fseq=%d, lseq=%d, diff=%d, tot_B=%d, tot_A=%d\n", fseq_n, lseq_n, lseq_n - fseq_n, total_n_pkts_B, total_n_pkts_A);\
	stop_ubertooth = 0;\
	return 1;}

#define COUNT_ADPTV_PKTS \
	if ( 0 != SHM2_read_buf1 ( ShmPTR_A, &slt_dat_A) ) {\
		if (( 0 != slt_dat_A.ofst625_1 ) || ( 0 != slt_dat_A.ofst625_2 ))\
			++ total_n_pkts_A;\
		slt_dat_A.ofst625_1 = 0;\
		slt_dat_A.ofst625_2 = 0;\
	}// main if statement


//uint8_t do_afh_est_hybrid 	( struct ShMemory  *ShmPTR,  struct ShMemory2  *ShmPTR2  );
uint8_t do_afh_est_hybrid2 	( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
//uint8_t do_afh_est_hybrid1 	( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
//uint8_t do_afh_est_hybrid 	( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
uint8_t do_afh_est_svm 		( struct ShMemory  *ShmPTR  );
uint8_t do_afh_est_pkt 		( struct ShMemory  *ShmPTR  );
uint8_t do_afh_est_pkt1 	( struct ShMemory  *ShmPTR  );
uint8_t do_afh_est_pkt2 	( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
uint8_t do_afh_est_svm2 	( struct ShMemory2  *ShmPTR_A,  struct ShMemory2  *ShmPTR_B  );
uint8_t do_afh_est_svm1 	( struct ShMemory  *ShmPTR  );
uint8_t do_svm_train_onetime 	( struct ShMemory  *ShmPTR  );
uint8_t set_afh			( struct ShMemory2 *ShmPTR_A, struct ShMemory2 *ShmPTR_B  );

uint8_t stop_ubertooth = 0; 

//////////////////////////////////
void	cleanup(int sig)
{
	sig = sig;
	stop_ubertooth = 1;
}
///////////////////////////////////
//int main ( int argc, char *argv[] )
int main (   )
{

	struct ShMemory2 *ShmPTR_A = _Get_Shmem2_ (ATTACH_SHMEM2, 'A');
	struct ShMemory2 *ShmPTR_B = _Get_Shmem2_ (ATTACH_SHMEM2, 'B');

	SHM2_init_read_indx ( ShmPTR_A, -6 );
	SHM2_init_read_indx ( ShmPTR_B, -6 );

	/* Clean up on exit. */
	signal(SIGINT,cleanup);
	signal(SIGQUIT,cleanup);
	signal(SIGTERM,cleanup);

//	do_afh_est_hybrid2 	(  ShmPTR_A, ShmPTR_B );
	do_afh_est_pkt2		(  ShmPTR_A, ShmPTR_B );
//	do_afh_est_svm2		(  ShmPTR_A, ShmPTR_B );
//	set_afh ( ShmPTR_A, ShmPTR_B );

//	do_svm_train_onetime 	(  ShmPTR );
//	do_afh_est_svm1		(  ShmPTR );
//	do_afh_est_pkt1		(  ShmPTR );

out:
	shmdt((void *) ShmPTR_A);
	shmdt((void *) ShmPTR_B);
	return 0;
}
//////////////////////////////////////////////////////////////////////////////
uint8_t set_afh	( struct ShMemory2  *ShmPTR_A, struct ShMemory2  *ShmPTR_B)
{
// this function read GT_AFH from network and send it to ADPTV
// Then it calculate captured pkts in both basic and adptv
	int 	empty_slts_A = 0, empty_slts_B = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t prev_GT_afh [ 10 ] ;

	struct _slt_buf slt_dat_A;
	struct _slt_buf slt_dat_B;

/////////////////////////////////////////////////////////////////////////////////
///// network section

	NETWORK_SETTING_MACRO ;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

//GT_afh [ 0 ] = 0x00;
//GT_afh [ 1 ] = 0x00;
//GT_afh [ 2 ] = 0x00;
//GT_afh [ 3 ] = 0xff;
//GT_afh [ 4 ] = 0xff;
//GT_afh [ 5 ] = 0xff;
//GT_afh [ 6 ] = 0xff;
//GT_afh [ 7 ] = 0xff;
//GT_afh [ 8 ] = 0xff;
//GT_afh [ 9 ] = 0xff;


while ( 1 )
{ // main While loop

	if ( 0 != compare_n_cpy ( prev_GT_afh, net_dat.network_GT_afh, 10  ) )
	{
		SHM2_set_GH_afh ( ShmPTR_A, net_dat.network_GT_afh );

		printf ("afh sent to adptv\n");

		print_afh_maps ( prev_GT_afh, net_dat.network_GT_afh );

	}// main if statement

//////////////////////////////////////////////////////////////////
	if ( 0 != SHM2_read_buf1 ( ShmPTR_B, &slt_dat_B) )
	{

		if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
		{
			++ total_n_pkts_B;


			slt_dat_B.ofst625_1 = 0;
			slt_dat_B.ofst625_2 = 0;
		}

//		print_afh_maps ( net_dat.network_GT_afh, prev_GT_afh );

	}// main if statement

//////////////////////////////////////////////////////////////////

	COUNT_ADPTV_PKTS;

	RECV_NET_DAT;
	PRINT_RESLT_AND_STOP;

} // main While loop


out1:
	close(sock);
	return 0;
}

//////////////////////////////////////////////////////////////
uint8_t do_afh_est_hybrid2 ( struct ShMemory2  *ShmPTR_A,  struct ShMemory2  *ShmPTR_B  )
{

	int 	i, j, empty_slts_B = 0, empty_slts_A = 0, train_alarm = 0, svm_predict_alarm = 0, pkt_predict_alarm = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t collected_afh_pkt [ 10 ], collected_local_label [ 10 ] ,
		prev_local_label [ 79 ], local_label [ 79 ];

memset ( collected_local_label, 0xff, 10);
memset ( collected_afh_pkt    , 0xff, 10);

collected_local_label [ 9 ] &= 0x7f;
collected_afh_pkt [ 9 ] &= 0x7f;


memset ( local_label, 1, 79);

	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	_init_svm_files ( & svm_dat, &f );

	struct _pkt_est_dat pkt_dat;
memset ( pkt_dat.pkt_label, 1, 79);

	struct _slt_buf slt_dat_B;
	struct _slt_buf slt_dat_A;
/////////////////////////////////////////////////////////////////////////////////
///// network section
	NETWORK_SETTING_MACRO;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

while ( 1 )
{ // main While loop

	if ( 0 != SHM2_read_buf1 ( ShmPTR_B, &slt_dat_B) )
	{

		if ( 0 < empty_slts_B  )
		{	
			-- empty_slts_B; 
			++ svm_dat.ch_rssi 		[ slt_dat_B.slt_ch ][ adjust_rssi ( slt_dat_B.slt_rssi ) ];
		}

		else 
		{

			++ svm_predict_alarm ; 
			++ pkt_predict_alarm ;
			++ train_alarm ;

			++ pkt_dat.n_visits 		[ slt_dat_B.slt_ch ];


			if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
			{

				++ pkt_dat.recvd_pkt	[ slt_dat_B.slt_ch ];
				++ total_n_pkts_B;

//				switch ( slt_dat_B.slt_ch )
//				{
//					case 15: case 14:		empty_slts_B = 2;
//					case 16: case 10: 
//					case 11: case 12: 
//					case 13: 			empty_slts_B = 1;
//					default: 			empty_slts_B = 0;
//				}

			}
			else // -1 == B_ptype
				++ svm_dat.ch_rssi 		[ slt_dat_B.slt_ch ][ adjust_rssi ( slt_dat_B.slt_rssi ) ];
		}

/////////////////////////// BEGIN NETWORK SECTION


//////////////////////////////////////////
// 400, 800, 1600, 3200, 6400, 9600, 12800
//		if ( 9600 < pkt_predict_alarm) 
		if ( 1600 < pkt_predict_alarm) 
		{
			pkt_predict_alarm = 0 ;
			pkt_bsd_predict_func 	( & pkt_dat  );

			collect_afh 		( collected_afh_pkt, pkt_dat.pkt_label  );
			compare_n_cpy 		( collected_local_label, collected_afh_pkt, 10  );

			memcpy 			( local_label , pkt_dat.pkt_label,79);
			memcpy 			( svm_dat.svm_label, pkt_dat.pkt_label, 79);
			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );


		}
/////////////////////////// BEGIN SVM SECTION

//		if ( ( 800 < train_alarm  ) && ( 0 ) )
		if   ( 600 < train_alarm  ) 
		{
			train_alarm = 0;
			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );
		}
/////////////////////////////////////////
//		if (266 < svm_predict) 
		if (800 < svm_predict_alarm) 
//		if (1600 < svm_predict) 
//		if (6400 < svm_predict) 
		{
			svm_predict_alarm = 0 ;
			memcpy 			( svm_dat.svm_label, local_label, 79);
			write_SVM_data_to_file 	( & svm_dat, &f, PRDCT_DATA  );
			classify_main 		( & svm_dat, &f  );

			for ( i = 0 ; i < 79; i ++)
			{
				if ( svm_dat.ch_est_svm [ i ] >= 1.2 ) 
					local_label [ i ] = CH_GOOD;

				else if ( svm_dat.ch_est_svm [ i ] <= -1.2 )
					local_label [ i ] = CH_BAD;

				else 
					local_label [ i ] = pkt_dat.pkt_label [ i ];
			}

			collect_afh ( collected_local_label, local_label  );

			if ( 0 != compare_n_cpy ( prev_local_label, local_label, 79  ) )
			{
				SHM2_set_GH_afh ( ShmPTR_A, collected_local_label );
				printf ("afh sent to adptv\n");
			}

			printf ("svm predict\n");

		}


		print_afh_maps2 ( net_dat.network_GT_afh, collected_afh_pkt, collected_local_label );

	}// main if statement
//////////////////////////////////

	COUNT_ADPTV_PKTS ;

	RECV_NET_DAT;
	PRINT_RESLT_AND_STOP ;

} // main While loop


out1:
	close(sock);
	return 0;
}
////////////////////////////////////////////////////////////////////////
uint8_t do_afh_est_pkt2 ( struct ShMemory2  *ShmPTR_A,  struct ShMemory2  *ShmPTR_B  )
{

	int 	i, j, empty_slts_B = 0, empty_slts_A = 0, train_alarm = 0, svm_predict_alarm = 0, pkt_predict_alarm = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t collected_afh_pkt [ 10 ], collected_local_label [ 10 ] ,
		prev_local_label [ 79 ], local_label [ 79 ];

memset ( collected_local_label, 0xff, 10);
memset ( collected_afh_pkt    , 0xff, 10);

collected_local_label [ 9 ] &= 0x7f;
collected_afh_pkt [ 9 ] &= 0x7f;


memset ( local_label, 1, 79);

	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	_init_svm_files ( & svm_dat, &f );

	struct _pkt_est_dat pkt_dat;
memset ( pkt_dat.pkt_label, 1, 79);

	struct _slt_buf slt_dat_B;
	struct _slt_buf slt_dat_A;
/////////////////////////////////////////////////////////////////////////////////
///// network section
	NETWORK_SETTING_MACRO;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

while ( 1 )
{ // main While loop

	if ( 0 != SHM2_read_buf1 ( ShmPTR_B, &slt_dat_B) )
	{

//		if ( 0 < empty_slts_B  )
//		{	
//			-- empty_slts_B; 
//			++ svm_dat.ch_rssi 		[ slt_dat_B.slt_ch ][ adjust_rssi ( slt_dat_B.slt_rssi ) ];
//		}
//
//		else 
		{

			++ svm_predict_alarm ; 
			++ pkt_predict_alarm ;
			++ train_alarm ;

			++ pkt_dat.n_visits 		[ slt_dat_B.slt_ch ];


			if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
			{

				++ pkt_dat.recvd_pkt	[ slt_dat_B.slt_ch ];
				++ total_n_pkts_B;

//				switch ( slt_dat_B.slt_ch )
//				{
//					case 15: case 14:		empty_slts_B = 2;
//					case 16: case 10: 
//					case 11: case 12: 
//					case 13: 			empty_slts_B = 1;
//					default: 			empty_slts_B = 0;
//				}

			}
			else // -1 == B_ptype
				++ svm_dat.ch_rssi 		[ slt_dat_B.slt_ch ][ adjust_rssi ( slt_dat_B.slt_rssi ) ];
		}

/////////////////////////// BEGIN NETWORK SECTION


//////////////////////////////////////////
// 400, 800, 1600, 3200, 6400, 9600, 12800
//		if ( 9600 < pkt_predict_alarm) 
		if ( 9600 < pkt_predict_alarm) 
		{
			pkt_predict_alarm = 0 ;
			pkt_bsd_predict_func 	( & pkt_dat  );

			collect_afh 		( collected_afh_pkt, pkt_dat.pkt_label  );
//			compare_n_cpy 		( collected_local_label, collected_afh_pkt, 10  );

//			memcpy 			( local_label , pkt_dat.pkt_label,79);
//			memcpy 			( svm_dat.svm_label, pkt_dat.pkt_label, 79);
//			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
//			learn_main 		( & svm_dat, &f  );

			if ( 0 != compare_n_cpy ( collected_local_label, collected_afh_pkt, 10  ) )
			{
				SHM2_set_GH_afh ( ShmPTR_A, collected_local_label );
				printf ("afh sent to adptv\n");
			}

		}
/////////////////////////// BEGIN SVM SECTION

//		if ( ( 800 < train_alarm  ) && ( 0 ) )
		if   ( (600 < train_alarm) && 0 ) 
		{
			train_alarm = 0;
			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );
		}
/////////////////////////////////////////
//		if (266 < svm_predict) 
		if ( (800 < svm_predict_alarm) && 0) 
//		if (1600 < svm_predict) 
//		if (6400 < svm_predict) 
		{
			svm_predict_alarm = 0 ;
			memcpy 			( svm_dat.svm_label, local_label, 79);
			write_SVM_data_to_file 	( & svm_dat, &f, PRDCT_DATA  );
			classify_main 		( & svm_dat, &f  );

			for ( i = 0 ; i < 79; i ++)
			{
				if ( svm_dat.ch_est_svm [ i ] >= 1.2 ) 
					local_label [ i ] = CH_GOOD;

				else if ( svm_dat.ch_est_svm [ i ] <= -1.2 )
					local_label [ i ] = CH_BAD;

				else 
					local_label [ i ] = pkt_dat.pkt_label [ i ];
			}

			collect_afh ( collected_local_label, local_label  );

//			if ( 0 != compare_n_cpy ( prev_local_label, local_label, 79  ) )
//			{
//				SHM2_set_GH_afh ( ShmPTR_A, collected_local_label );
//				printf ("afh sent to adptv\n");
//			}
//
			printf ("svm predict\n");

		}


		print_afh_maps ( net_dat.network_GT_afh, collected_afh_pkt );

	}// main if statement
//////////////////////////////////

	COUNT_ADPTV_PKTS ;

	RECV_NET_DAT;
	PRINT_RESLT_AND_STOP ;

} // main While loop


out1:
	close(sock);
	return 0;
}
/////////////////////////////////////////////////////////////////////////////////////////
uint8_t do_afh_est_svm2 ( struct ShMemory2  *ShmPTR_A,  struct ShMemory2  *ShmPTR_B  )
{

	int 	i, j, empty_slts_B = 0, empty_slts_A = 0, train_alarm = 0, svm_predict_alarm = 0, pkt_predict_alarm = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t collected_afh_pkt [ 10 ], collected_local_label [ 10 ] ,
		prev_local_label [ 79 ], local_label [ 79 ];

memset ( collected_local_label, 0xff, 10);
memset ( collected_afh_pkt    , 0xff, 10);

collected_local_label [ 9 ] &= 0x7f;
collected_afh_pkt [ 9 ] &= 0x7f;


memset ( local_label, 1, 79);

	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	_init_svm_files ( & svm_dat, &f );

	struct _pkt_est_dat pkt_dat;
memset ( pkt_dat.pkt_label, 1, 79);

	struct _slt_buf slt_dat_B;
	struct _slt_buf slt_dat_A;
/////////////////////////////////////////////////////////////////////////////////
///// network section
	NETWORK_SETTING_MACRO;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

while ( 1 )
{ // main While loop

	if ( 0 != SHM2_read_buf1 ( ShmPTR_B, &slt_dat_B) )
	{

		if ( 0 < empty_slts_B  )
		{	
			-- empty_slts_B; 
			++ svm_dat.ch_rssi 		[ slt_dat_B.slt_ch ][ adjust_rssi ( slt_dat_B.slt_rssi ) ];
		}

		else 
		{

			++ svm_predict_alarm ; 
			++ pkt_predict_alarm ;
			++ train_alarm ;

			++ pkt_dat.n_visits 		[ slt_dat_B.slt_ch ];


			if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
			{

				++ pkt_dat.recvd_pkt	[ slt_dat_B.slt_ch ];
				++ total_n_pkts_B;

//				switch ( slt_dat_B.slt_ch )
//				{
//					case 15: case 14:		empty_slts_B = 2;
//					case 16: case 10: 
//					case 11: case 12: 
//					case 13: 			empty_slts_B = 1;
//					default: 			empty_slts_B = 0;
//				}

			}
			else // -1 == B_ptype
				++ svm_dat.ch_rssi 		[ slt_dat_B.slt_ch ][ adjust_rssi ( slt_dat_B.slt_rssi ) ];
		}

/////////////////////////// BEGIN NETWORK SECTION


//////////////////////////////////////////
// 400, 800, 1600, 3200, 6400, 9600, 12800
//		if ( 9600 < pkt_predict_alarm) 
		if (( 1600 < pkt_predict_alarm) && 0 )
		{
			pkt_predict_alarm = 0 ;
			pkt_bsd_predict_func 	( & pkt_dat  );

			collect_afh 		( collected_afh_pkt, pkt_dat.pkt_label  );
			compare_n_cpy 		( collected_local_label, collected_afh_pkt, 10  );

			memcpy 			( local_label , pkt_dat.pkt_label,79);
			memcpy 			( svm_dat.svm_label, pkt_dat.pkt_label, 79);
			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );


		}
/////////////////////////// BEGIN SVM SECTION

//		if ( ( 800 < train_alarm  ) && ( 0 ) )
		if   ( 600 < train_alarm  ) 
		{
			train_alarm = 0;
			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );
		}
/////////////////////////////////////////
//		if (266 < svm_predict) 
		if (800 < svm_predict_alarm) 
//		if (1600 < svm_predict) 
//		if (6400 < svm_predict) 
		{
			svm_predict_alarm = 0 ;
			memcpy 			( svm_dat.svm_label, local_label, 79);
			write_SVM_data_to_file 	( & svm_dat, &f, PRDCT_DATA  );
			classify_main 		( & svm_dat, &f  );

			for ( i = 0 ; i < 79; i ++)
			{


				if ( svm_dat.ch_est_svm [ i ] >= 0.8 ) 
					local_label [ i ] = CH_GOOD;

				else if ( svm_dat.ch_est_svm [ i ] <= -0.8 )
					local_label [ i ] = CH_BAD;

				else 
					local_label [ i ] = pkt_dat.pkt_label [ i ];
			}

			collect_afh ( collected_local_label, local_label  );

			if ( 0 != compare_n_cpy ( prev_local_label, local_label, 79  ) )
			{
				SHM2_set_GH_afh ( ShmPTR_A, collected_local_label );
				printf ("afh sent to adptv\n");
			}

			printf ("svm predict\n");

		}


		print_afh_maps2 ( net_dat.network_GT_afh, collected_afh_pkt, collected_local_label );

	}// main if statement
//////////////////////////////////

	COUNT_ADPTV_PKTS ;

	RECV_NET_DAT;
	PRINT_RESLT_AND_STOP ;

} // main While loop


out1:
	close(sock);
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////
uint8_t do_afh_est_pkt1 ( struct ShMemory  *ShmPTR  )
{

	int 	i, j, empty_slts_B = 0, empty_slts_A = 0, train_alarm = 0, svm_predict_alarm = 0, pkt_predict_alarm = 0, 
		local_B_indx = 0, local_A_indx = 0, curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t collected_afh_pkt [ 10 ], collected_local_label [ 10 ] ;
	uint8_t prev_local_label [ 79 ], local_label [ 79 ];
memset (local_label, 1, 79);


	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	_init_svm_files ( & svm_dat, &f );

	struct _pkt_est_dat pkt_dat;
memset (pkt_dat.pkt_label, 1, 79);
	struct _channel_dat basic_ch_dat;
	struct _channel_dat adptv_ch_dat;

/////////////////////////////////////////////////////////////////////////////////
///// network section
///// network section

	NETWORK_SETTING_MACRO ;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready
//	while ( STD_SPEED != ShmPTR->basic_pkt_status) 
//		;

	local_A_indx 	= SHM_get_adptv_buf_idx ( ShmPTR ) - 6 ;
	local_B_indx 	= SHM_get_basic_buf_idx ( ShmPTR ) - 6 ;


while ( 1 )
{ // main While loop

	if ( local_B_indx <= ( SHM_get_basic_buf_idx ( ShmPTR ) - 6) )
	{

		SHM_read_B_buf ( ShmPTR, &basic_ch_dat , local_B_indx);

		++ local_B_indx;
//		print_ch_dat ( & basic_ch_dat );
//		dat_analysis ( &basic_ch_dat, &pkt_dat, &svm_dat  );
//////////////////////////////////////////////

		if ( 0 < empty_slts_B  )
		{	
			-- empty_slts_B; 
			++ svm_dat.ch_rssi 		[ basic_ch_dat.ch ][ adjust_rssi ( basic_ch_dat.rssi ) ];
		}

		else 
		{

			++ svm_predict_alarm ; 
			++ pkt_predict_alarm ;
			++ train_alarm ;

			++ pkt_dat.n_visits 		[ basic_ch_dat.ch ];

			if ( -1 != basic_ch_dat.ptype )  // check if it has a pkt
			{
				++ pkt_dat.recvd_pkt	[ basic_ch_dat.ch ];
				++ total_n_pkts_B;

				switch ( basic_ch_dat.ch )
				{
					case 15: case 14:		empty_slts_B = 2;
					case 16: case 10: 
					case 11: case 12: 
					case 13: 			empty_slts_B = 1;
					default: 			empty_slts_B = 0;
				}

			}
			else // -1 == B_ptype
				++ svm_dat.ch_rssi 		[ basic_ch_dat.ch ][ adjust_rssi ( basic_ch_dat.rssi ) ];
		}

/////////////////////////// BEGIN NETWORK SECTION
		RECV_NET_DAT;

//////////////////////////////////////////
// 400, 800, 1600, 3200, 6400, 9600, 12800
		if ( ( 9600 < pkt_predict_alarm) &&  1  )
		{
			pkt_predict_alarm = 0 ;
			pkt_bsd_predict_func 	( & pkt_dat  );
			_reset_pkt_buffers	( & pkt_dat  );

//			if  ( 0 != strncmp ( ( char *) collected_afh_pkt, ( char *)  prev_collected_afh_pkt, 10)  ) 
			{
				memcpy 			( local_label      , pkt_dat.pkt_label,79);
//				memcpy 			( svm_dat.svm_label, pkt_dat.pkt_label, 79);
//				write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
//				learn_main 		( & svm_dat, &f  );
			}

			if ( 0 != memcmp ( prev_local_label, local_label, 79  ) )
			{
				memcpy ( prev_local_label, local_label, 79  );
				collect_afh ( local_label, collected_local_label );
				SHM_set_GH_afh (ShmPTR, collected_local_label);
				printf ("afh sent to adptv\n");
			}

		}
/////////////////////////// BEGIN SVM SECTION

		if ( ( 800 < train_alarm  ) && ( 0 ) )
//		if   ( 600 < train_alarm  ) 
		{
			train_alarm = 0;
			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );
		}
/////////////////////////////////////////
//		if ( (266 < svm_predict) && ( ACTIVE_SVM_PREDICT = 1 ) )
		if ( (800 < svm_predict_alarm) && ( 0 ) )
//		if ( (1600 < svm_predict) && ( ACTIVE_SVM_PREDICT = 1 ) )
//		if ( (6400 < svm_predict) && ( ACTIVE_SVM_PREDICT = 1 ) )
		{
			svm_predict_alarm = 0 ;
			memcpy 			( svm_dat.svm_label, local_label, 79);
			write_SVM_data_to_file 	( & svm_dat, &f, PRDCT_DATA  );
			classify_main 		( & svm_dat, &f  );

			for ( i = 0 ; i < 79; i ++)
			{
				if ( svm_dat.ch_est_svm [ i ] >= 1.2 ) 
					local_label [ i ] = CH_GOOD;
				else 
					local_label [ i ] = pkt_dat.pkt_label [ i ];

//				else if ( svm_dat.ch_est_svm [ i ] <= -1.2 )
				if ( svm_dat.ch_est_svm [ i ] <= -1.2 )  
					local_label [ i ] = CH_BAD;
				else 
					local_label [ i ] = pkt_dat.pkt_label [ i ];
			}

			_reset_rssi_buffers ( & svm_dat  );

			if ( 0 != memcmp ( prev_local_label, local_label, 79  ) )
			{
				memcpy ( prev_local_label, local_label, 79  );
//				collect_afh ( local_label, collected_local_label );
//				SHM_set_GH_afh (ShmPTR, collected_local_label);
				printf ("afh sent to adptv\n");
			}

			printf ("svm predict\n");

		}

		memcpy ( local_label, pkt_dat.pkt_label, 79  );
		collect_afh ( local_label, collected_afh_pkt );
		print_afh_maps ( net_dat.network_GT_afh, collected_afh_pkt);
//		collect_afh ( local_label      , collected_local_label );
//		print_afh_maps2 ( net_dat.network_GT_afh, collected_afh_pkt, collected_local_label );

/////////////////////////// END SVM SECTION

	}// main if statement

	if ( local_A_indx <= ( SHM_get_adptv_buf_idx ( ShmPTR ) - 6) )
	{
		SHM_read_A_buf ( ShmPTR, &adptv_ch_dat, local_A_indx);
		++ local_A_indx;

//		print_ch_dat ( & adptv_ch_dat );

		if ( 0 < empty_slts_A  )
		{	
			-- empty_slts_A;
		}

		else 
		{
			if ( -1 != adptv_ch_dat.ptype )  // check if it has a pkt
			{
				++ total_n_pkts_A;

				switch ( adptv_ch_dat.ch )
				{
					case 15: case 14:		empty_slts_A = 2;
					case 16: case 10: 
					case 11: case 12: 
					case 13: 			empty_slts_A = 1;
					default: 			empty_slts_A = 0;
				}
			}
		}


	}// main if statement


	if ( 1 == stop_ubertooth )
	{
		lseq_n  = curr_seq;
		printf ("fseq=%d, lseq=%d, diff=%d, tot_B=%d, tot_A=%d\n", fseq_n, lseq_n, lseq_n - fseq_n, total_n_pkts_B, total_n_pkts_A);
		stop_ubertooth = 0;
		return 1;
	}
} // main While loop


out1:
	close(sock);
	return 0;
}
//////////////////////////////////////////////////////////////////////////////////////
uint8_t do_afh_est_svm1 ( struct ShMemory  *ShmPTR  )
{

	int 	i, j, empty_slts_B = 0, empty_slts_A = 0, train_alarm = 0, svm_predict_alarm = 0, pkt_predict_alarm = 0, 
		local_B_indx = 0, local_A_indx = 0, curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t collected_afh_pkt [ 10 ], collected_local_label [ 10 ] ;
	uint8_t prev_local_label [ 79 ], local_label [ 79 ];
memset (local_label, 1, 79);
	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	_init_svm_files ( & svm_dat, &f );

//	strcpy ( f.modelfile, "svm_model_onetimetrain_jam40");//"svm_model");
//	strcpy ( f.modelfile, "svm_model_onetimetrain_jam20");//"svm_model");

	struct _pkt_est_dat pkt_dat;

	struct _channel_dat basic_ch_dat;
	struct _channel_dat adptv_ch_dat;

/////////////////////////////////////////////////////////////////////////////////
///// network section
///// network section

	NETWORK_SETTING_MACRO ;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready
//	while ( STD_SPEED != ShmPTR->basic_pkt_status) 
//		;

	local_A_indx 	= SHM_get_adptv_buf_idx ( ShmPTR ) - 6 ;
	local_B_indx 	= SHM_get_basic_buf_idx ( ShmPTR ) - 6 ;


while ( 1 )
{ // main While loop

	if ( local_B_indx <= ( SHM_get_basic_buf_idx ( ShmPTR ) - 6) )
	{

		SHM_read_B_buf ( ShmPTR, &basic_ch_dat , local_B_indx);

		++ local_B_indx;
//		print_ch_dat ( & basic_ch_dat );
//		dat_analysis ( &basic_ch_dat, &pkt_dat, &svm_dat  );
//////////////////////////////////////////////

		if ( 0 < empty_slts_B  )
		{	
			-- empty_slts_B; 
			++ svm_dat.ch_rssi 		[ basic_ch_dat.ch ][ adjust_rssi ( basic_ch_dat.rssi ) ];
		}

		else 
		{

			++ svm_predict_alarm ; 
			++ pkt_predict_alarm ;
			++ train_alarm ;

			++ pkt_dat.n_visits 		[ basic_ch_dat.ch ];

			if ( -1 != basic_ch_dat.ptype )  // check if it has a pkt
			{
				++ pkt_dat.recvd_pkt	[ basic_ch_dat.ch ];
				++ total_n_pkts_B;

				switch ( basic_ch_dat.ch )
				{
					case 15: case 14:		empty_slts_B = 2; break;
					case 16: case 10: 
					case 11: case 12: 
					case 13: 			empty_slts_B = 1; break;
					default: 			empty_slts_B = 0; break;
				}

			}
			else // -1 == B_ptype
				++ svm_dat.ch_rssi 		[ basic_ch_dat.ch ][ adjust_rssi ( basic_ch_dat.rssi ) ];
		}

/////////////////////////// BEGIN NETWORK SECTION
		RECV_NET_DAT;

//////////////////////////////////////////
// 400, 800, 1600, 3200, 6400, 9600, 12800
		if ( ( 9600 < pkt_predict_alarm) &&  0  )
		{
			pkt_predict_alarm = 0 ;
			pkt_bsd_predict_func 	( & pkt_dat  );
			_reset_pkt_buffers	( & pkt_dat  );

//			if  ( 0 != strncmp ( ( char *) collected_afh_pkt, ( char *)  prev_collected_afh_pkt, 10)  ) 
			{
				memcpy 			( local_label      , pkt_dat.pkt_label,79);
				memcpy 			( svm_dat.svm_label, pkt_dat.pkt_label, 79);
				write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
				learn_main 		( & svm_dat, &f  );
			}

		}
/////////////////////////// BEGIN SVM SECTION

		if ( ( 800 < train_alarm  ) && ( 0 ) )
//		if   ( 600 < train_alarm  ) 
		{
			train_alarm = 0;
			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );
		}
/////////////////////////////////////////
//		if ( (266 < svm_predict) && ( ACTIVE_SVM_PREDICT = 1 ) )
		if ( (800 < svm_predict_alarm) && ( 1 ) )
//		if ( (1600 < svm_predict) && ( ACTIVE_SVM_PREDICT = 1 ) )
//		if ( (6400 < svm_predict) && ( ACTIVE_SVM_PREDICT = 1 ) )
		{
			svm_predict_alarm = 0 ;
//			memcpy 			( svm_dat.svm_label, local_label, 79);
			write_SVM_data_to_file 	( & svm_dat, &f, PRDCT_DATA  );
			classify_main 		( & svm_dat, &f  );

			for ( i = 0 ; i < 79; i ++)
			{
				if ( svm_dat.ch_est_svm [ i ] >= 0.7 ) 
					local_label [ i ] = CH_GOOD;
				else 
					local_label [ i ] = CH_BAD;

//				else if ( svm_dat.ch_est_svm [ i ] <= -1.2 )
//				if ( svm_dat.ch_est_svm [ i ] <= -0.1 )  
//					local_label [ i ] = CH_BAD;
////				else 
////					local_label [ i ] = pkt_dat.pkt_label [ i ];
			}

			_reset_rssi_buffers ( & svm_dat  );

			if ( 0 != memcmp ( prev_local_label, local_label, 79  ) )
			{
				memcpy ( prev_local_label, local_label, 79  );
				collect_afh ( local_label, collected_local_label );
				SHM_set_GH_afh (ShmPTR, collected_local_label);
				printf ("afh sent to adptv\n");
			}

			printf ("svm predict\n");

		}

//		collect_afh ( pkt_dat.pkt_label, collected_afh_pkt );
//		memcpy	( local_label, svm_dat.svm_label,79);
		collect_afh ( local_label      , collected_local_label );
		print_afh_maps ( net_dat.network_GT_afh, collected_local_label );
//		print_afh_maps2 ( net_dat.network_GT_afh, collected_afh_pkt, collected_local_label );

/////////////////////////// END SVM SECTION

	}// main if statement

	if ( local_A_indx <= ( SHM_get_adptv_buf_idx ( ShmPTR ) - 6) )
	{
		SHM_read_A_buf ( ShmPTR, &adptv_ch_dat, local_A_indx);
		++ local_A_indx;

//		print_ch_dat ( & adptv_ch_dat );

		if ( 0 < empty_slts_A  )
		{	
			-- empty_slts_A;
		}

		else 
		{
			if ( -1 != adptv_ch_dat.ptype )  // check if it has a pkt
			{
				++ total_n_pkts_A;

				switch ( adptv_ch_dat.ch )
				{
					case 15: case 14:		empty_slts_A = 2;
					case 16: case 10: 
					case 11: case 12: 
					case 13: 			empty_slts_A = 1;
					default: 			empty_slts_A = 0;
				}
			}
		}


	}// main if statement


	if ( 1 == stop_ubertooth )
	{
		lseq_n  = curr_seq;
		printf ("fseq=%d, lseq=%d, diff=%d, tot_B=%d, tot_A=%d\n", fseq_n, lseq_n, lseq_n - fseq_n, total_n_pkts_B, total_n_pkts_A);
		stop_ubertooth = 0;
		return 1;
	}
} // main While loop


out1:
	close(sock);
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////
//	strcpy ( loc_dat->modelfile, 		"svm_model_onetimetrain_jam40");//"svm_model");
///////////////////////////////////////////////////////////////////////////////////
uint8_t do_afh_est_svm ( struct ShMemory  *ShmPTR  )
{

	int 	i, j,  empty_slts = 0, empty_slts_A = 0, svm_predict_alarm = 0, local_B_indx = 0, local_A_indx = 0 ,
		total_no_pkts_A = 0, total_no_pkts_B = 0, curr_seq = 0, fseq_n= 0, lseq_n = 0;

	uint8_t prev_local_label [ 79 ], local_label [ 79 ], collected_afh_svm [ 10 ];
memset ( local_label, 1, 79 );
	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	
	_init_svm_files ( & svm_dat, &f );

//	strcpy ( f.modelfile, "svm_model_onetimetrain_jam40");//"svm_model");
	strcpy ( f.modelfile, "svm_model_onetimetrain_jam20");//"svm_model");
	
	struct _channel_dat basic_ch_dat;
	struct _channel_dat adptv_ch_dat;

/////////////////////////////////////////////////////////////////////////////////
///// network section
///// network section

	NETWORK_SETTING_MACRO ;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready
//	while ( STD_SPEED != ShmPTR->basic_pkt_status) 
//		;

	local_A_indx 		= SHM_get_adptv_buf_idx ( ShmPTR ) - 6 ;
	local_B_indx 		= SHM_get_basic_buf_idx ( ShmPTR ) - 6 ;

while ( 1 )
{ // main While loop

	if ( local_B_indx <= ( SHM_get_basic_buf_idx ( ShmPTR ) - 6) )
	{

		SHM_read_B_buf ( ShmPTR, &basic_ch_dat , local_B_indx);
			
		++ local_B_indx;
//		print_ch_dat ( & basic_ch_dat );

///////////////////////////////////////////////////////////////////////////////////
		if ( 0 < empty_slts  )
		{	
			-- empty_slts; 
			++ svm_dat.ch_rssi 	[ basic_ch_dat.ch ][ adjust_rssi ( basic_ch_dat.rssi ) ];
		}

		else 
		{
//			++ loc_dat.n_visits 		[ B_ch ];
////			++ loc_dat.ch_rssi 		[ B_ch ][ get_rssi ( -54 + B_rssi ) ];
			++ svm_predict_alarm ; 
//			++ pkt_bsd_predict ;
//			++ train_alarm ;

			if ( -1 !=  basic_ch_dat.ptype )  // check if it has a pkt
			{
//				++ loc_dat.n_pkt	[ basic_ch_dat.ch ];

				switch (  basic_ch_dat.ch )
				{
					case 15: case 14:		empty_slts = 2;
					case 16: case 10: 
					case 11: case 12: case 13: 	empty_slts = 1;
					default: 			empty_slts = 0;
				}

			}
			else // -1 == B_ptype
				++ svm_dat.ch_rssi 	[ basic_ch_dat.ch ][ adjust_rssi ( basic_ch_dat.rssi ) ];
		}
///////////////////////////////////////////////////////////////////////////////////
/////////////////////////// BEGIN SVM SECTION

		RECV_NET_DAT;

/////////////////////////////////
//		if ( (266 < svm_predict) && ( ACTIVE_SVM_PREDICT = 1 ) )
		if ( (800 < svm_predict_alarm) && ( 1 ) )
//		if ( (1600 < svm_predict) && ( ACTIVE_SVM_PREDICT = 1 ) )
//		if ( (6400 < svm_predict) && ( ACTIVE_SVM_PREDICT = 1 ) )
		{
			svm_predict_alarm = 0 ;
//			memcpy 			( svm_dat.svm_label, local_label, 79);
			write_SVM_data_to_file 	( & svm_dat, &f, PRDCT_DATA  );
			classify_main 		( & svm_dat, &f  );

			for ( i = 0 ; i < 79; i ++)
			{
				if ( svm_dat.ch_est_svm [ i ] >= 0.5 ) 
					local_label [ i ] = CH_GOOD;
//				else 
//					local_label [ i ] = pkt_dat.pkt_label [ i ];

//				else if ( svm_dat.ch_est_svm [ i ] <= -1.2 )
				if ( svm_dat.ch_est_svm [ i ] <= -0.5 )  
					local_label [ i ] = CH_BAD;
//				else 
//					local_label [ i ] = pkt_dat.pkt_label [ i ];

			}

			_reset_rssi_buffers ( & svm_dat  );

			if ( 0 != memcmp ( prev_local_label, local_label, 79  ) )
			{
				memcpy ( prev_local_label, local_label, 79  );
//				collect_afh ( local_label, collected_afh_svm );
//				SHM_set_GH_afh (ShmPTR, collected_afh_svm);
				printf ("afh sent to adptv\n");
			}

			printf ("svm predict\n");

		}

		collect_afh ( local_label, collected_afh_svm );
		print_afh_maps ( net_dat.network_GT_afh, collected_afh_svm );

/////////////////////////// END SVM SECTION

	}// main if statement


	if ( local_A_indx <= (ShmPTR->bufa_pkt_idx - 6) )
	{
		SHM_read_A_buf ( ShmPTR, &adptv_ch_dat, local_A_indx);
		++ local_A_indx;
//		print_ch_dat ( & basic_ch_dat );
//////////////////////////////////
		if ( 0 < empty_slts_A  )
		{	
			-- empty_slts_A; 
		}

		else 
		{
			if ( -1 != adptv_ch_dat.ptype )  // check if it has a pkt
			{
				++ total_no_pkts_A ; 
				switch ( adptv_ch_dat.ch )
				{
					case 15: case 14:	empty_slts_A = 2;
					case 10: case 11: 
					case 12: case 13: 	empty_slts_A = 1;
					default: 		empty_slts_A = 0;

				}
			}
		}


	}// main if statement

	if ( 1 == stop_ubertooth )
	{

		lseq_n  = curr_seq;
		printf ("fseq=%d, lseq=%d, diff=%d, tot_B=%d, tot_A=%d\n", fseq_n, lseq_n, lseq_n - fseq_n, total_no_pkts_B, total_no_pkts_A);
		stop_ubertooth = 0;
		return 1;
	}

} // main While loop


out1:
	close(sock);
	return 0;
}

//////////////////////////////////////////////////////////////////////////////
uint8_t do_afh_est_pkt ( struct ShMemory  *ShmPTR  )
{

	int 	i, j,  empty_slts = 0, empty_slts_A = 0, train_alarm = 0, pkt_predict_alarm = 0, local_B_indx = 0, local_A_indx = 0 ,
		total_no_pkts_A = 0, total_no_pkts_B = 0, curr_seq = 0, fseq_n= 0, lseq_n = 0;

	uint8_t collected_afh_pkt [ 10 ], prev_pkt_label [79] ;
memset ( collected_afh_pkt, 1, 10 );
memset ( prev_pkt_label, 1, 79 );
	struct _pkt_est_dat pkt_dat;
	
	struct _channel_dat basic_ch_dat;
	struct _channel_dat adptv_ch_dat;

/////////////////////////////////////////////////////////////////////////////////
///// network section
///// network section

	NETWORK_SETTING_MACRO ;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready
//	while ( STD_SPEED != ShmPTR->basic_pkt_status) 
//		;

	local_A_indx 		= SHM_get_adptv_buf_idx ( ShmPTR ) - 6 ;
	local_B_indx 		= SHM_get_basic_buf_idx ( ShmPTR ) - 6 ;

while ( 1 )
{ // main While loop

	if ( local_B_indx <= (ShmPTR->bufb_pkt_idx - 6) )
	{
		SHM_read_B_buf ( ShmPTR, &basic_ch_dat , local_B_indx);
			
		++ local_B_indx;
//		print_ch_dat ( & basic_ch_dat );
///////////////////////////////////////////////////////////////////////////////////
		if ( 0 < empty_slts  )
		{	
			-- empty_slts; 
//			++ svm_dat.ch_rssi 		[ basic_ch_dat.ch ][ adjust_rssi ( -54 + basic_ch_dat.rssi ) ];
		}

		else 
		{
			++ pkt_dat.n_visits 		[ basic_ch_dat.ch ];
////			++ loc_dat.ch_rssi 		[ B_ch ][ get_rssi ( -54 + B_rssi ) ];
//			++ svm_predict_alarm ; 
			++ pkt_predict_alarm ;
//			++ train_alarm ;

			if ( -1 != basic_ch_dat.ptype )  // check if it has a pkt
			{
				++ pkt_dat.recvd_pkt	[ basic_ch_dat.ch ];
				++ total_no_pkts_B;

				switch ( basic_ch_dat.ch )
				{
					case 15: case 14:		empty_slts = 2;
					case 16: case 10: case 11: 
					case 12: case 13: 		empty_slts = 1;
					default: 			empty_slts = 0;
				}

			}
//			else // -1 == B_ptype
//				++ svm_dat.ch_rssi 		[ basic_ch_dat.ch ][ adjust_rssi ( -54 + basic_ch_dat.rssi ) ];
		}

/////////////////////////// BEGIN NETWORK SECTION
		RECV_NET_DAT;

/////////////////////////// END PKT_BASED SECTION
// 400, 800, 1600, 3200, 6400, 9600, 12800

		if ( ( 9600 < pkt_predict_alarm) &&  1  )
		{
			pkt_predict_alarm = 0 ;
printf ("to pkd bsd\n");
			pkt_bsd_predict_func 	( & pkt_dat  );
printf ("out pkd bsd\n");
			_reset_pkt_buffers	( & pkt_dat  );

			if ( 0 != memcmp ( prev_pkt_label, pkt_dat.pkt_label, 79  ) )
			{
				memcpy ( prev_pkt_label, pkt_dat.pkt_label, 79  );
//				collect_afh ( pkt_dat.pkt_label, collected_afh_pkt );
//				SHM_set_GH_afh (ShmPTR, collected_afh_pkt);
				printf ("afh sent to adptv\n");
			}

		}
		collect_afh ( pkt_dat.pkt_label, collected_afh_pkt );
		print_afh_maps ( net_dat.network_GT_afh, collected_afh_pkt);
///////////////////////////// SET AFH for ADPTV hopper

	}// main if statement

	if ( local_A_indx <= (ShmPTR->bufa_pkt_idx - 6) )
	{

		SHM_read_A_buf ( ShmPTR, &adptv_ch_dat, local_A_indx);
		++ local_A_indx;

//		print_ch_dat ( & basic_ch_dat );
////////////////////////////////////////////////

		if ( 0 < empty_slts_A  )
		{	
			-- empty_slts_A; 
		}

		else 
		{

			if ( -1 != adptv_ch_dat.ptype )  // check if it has a pkt
			{
				++ total_no_pkts_A ; 
				switch ( adptv_ch_dat.ch )
				{
					case 15: case 14:	empty_slts_A = 2;
					case 10: case 11: 
					case 12: case 13: 	empty_slts_A = 1;
					default: 		empty_slts_A = 0;

				}
			}
		}


	}// main if statement


	if ( 1 == stop_ubertooth )
	{

		lseq_n  = curr_seq;
		printf ("fseq=%d, lseq=%d, diff=%d, tot_B=%d, tot_A=%d\n", fseq_n, lseq_n, lseq_n - fseq_n, total_no_pkts_B, total_no_pkts_A);
		stop_ubertooth = 0;
		return 1;
	}
} // main While loop


out1:
	close(sock);
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
uint8_t do_svm_train_onetime ( struct ShMemory  *ShmPTR  )
{
	int 	i, j,  empty_slts, train_alarm = 0, local_B_indx = 0 ;

	uint8_t afh_GT_buffer [ 10 ], collected_afh_svm [ 10 ] ;
	memset (afh_GT_buffer, 0, sizeof ( afh_GT_buffer ));

	struct _svm_est_dat svm_dat;
	struct _svm_files f;

	_init_svm_files ( & svm_dat, &f );

	struct _channel_dat basic_ch_dat;
/////////////////////////////////////////////////////////////////////////////////
///// network section
///// network section

	NETWORK_SETTING_MACRO ;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready
//	while ( STD_SPEED != ShmPTR->basic_pkt_status) 
//		;

	local_B_indx 		= SHM_get_basic_buf_idx ( ShmPTR ) - 6 ;

while ( 1 )
{ // main While loop


	if ( local_B_indx <= ( SHM_get_basic_buf_idx ( ShmPTR ) - 6) )
	{

		SHM_read_B_buf ( ShmPTR, &basic_ch_dat , local_B_indx);
		++ local_B_indx;
//		print_ch_dat ( & basic_ch_dat );
///////////////////////////////////////////////////////////////////////////////////
		if ( 0 < empty_slts  )
		{	
			-- empty_slts; 
			++ svm_dat.ch_rssi 		[ basic_ch_dat.ch ][ adjust_rssi ( basic_ch_dat.rssi ) ];
		}

		else 
		{
//			++ pkt_dat.n_visits 		[ basic_ch_dat.ch ];
//			++ loc_dat.ch_rssi 		[ B_ch ][ get_rssi ( -54 + B_rssi ) ];
			++ train_alarm ;

			if ( -1 != basic_ch_dat.ptype )  // check if it has a pkt
			{
//				++ pkt_dat.recvd_pkt	[ basic_ch_dat.ch ];

				switch ( basic_ch_dat.ch )
				{
					case 15: case 14:		empty_slts = 2;
					case 16: case 10: 
					case 11: case 12: case 13: 	empty_slts = 1;
					default: 			empty_slts = 0;
				}

			}
			else // -1 == B_ptype
				++ svm_dat.ch_rssi 		[ basic_ch_dat.ch ][ adjust_rssi ( basic_ch_dat.rssi ) ];
		}

/////////////////////////// rcev from network SECTION

		recsize = recvfrom(sock, (void *) &net_dat, sizeof (struct _network_dat), MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);

		// if we have a new GT afh, then do train SVM
//		if (( 0 != strncmp ( ( char *) afh_GT_buffer, ( char *)  prev_afh_GT, 10)  ) && (0) )
//		{
//
//			strncpy 		( prev_afh_GT, afh_GT_buffer, 10);
//
//			un_collect_afh		( afh_GT_buffer, svm_label );
//
//			write_SVM_data_to_file  ( & loc_dat,     svm_label, TRAIN_DATA  );
//
//			learn_main 		( & loc_dat  );
//
//		}

/////////////////////////// BEGIN SVM TRAIN SECTION
//		if ( ( 800 < train_alarm  ) && ( 0 ) )
		if   ( 600 < train_alarm  ) 
		{
			train_alarm = 0;
			un_collect_afh		( net_dat.network_GT_afh, svm_dat.svm_label );
			write_SVM_data_to_file  ( & svm_dat, &f, TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );
//			_reset_local_buffers_pkt 	( & loc_dat  );
		}

		print_afh_maps ( net_dat.network_GT_afh, collected_afh_svm );

/////////////////////////// END SVM SECTION

	}// main if statement


	if ( 1 == stop_ubertooth )
	{
		stop_ubertooth = 0;
//		return 1;
		break;
	}

} // main While loop


out:
	close(sock);
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
int get_basic_pkt_rate ( struct ShMemory  *ShmPTR  )
{

	int 	i, j,  empty_slts, train_alarm = 0, local_B_indx = 0 , total_no_pkts_B = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0;

	struct _pkt_est_dat pkt_dat;

	struct _channel_dat basic_ch_dat;
/////////////////////////////////////////////////////////////////////////////////
///// network section
///// network section

	NETWORK_SETTING_MACRO ;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready
//	while ( STD_SPEED != ShmPTR->basic_pkt_status) 
//		;

	local_B_indx 		= SHM_get_basic_buf_idx ( ShmPTR ) - 6 ;


while ( 1 )
{ // main While loop


	if ( local_B_indx <= ( SHM_get_basic_buf_idx ( ShmPTR ) - 6) )
	{

		SHM_read_B_buf ( ShmPTR, &basic_ch_dat , local_B_indx);
			
		++ local_B_indx;

//		printf ("B  ptyp=%02d, ch=%u, rssi=%d, B_och=%u, B_indx=%d, ptime=%u\n", 
//			B_ptype,
//			B_ch,
//			-54 + B_rssi  ,
//			B_och,
//			B_indx,
//			B_ptime
//			);


		if ( 0 < empty_slts  )
		{	
			-- empty_slts; 
//			++ loc_dat.ch_rssi 		[ B_ch ][ get_rssi ( -54 + B_rssi ) ];
		}

		else 
		{
//			++ loc_dat.n_visits 		[ B_ch ];

			if ( -1 != basic_ch_dat.ptype )  // check if it has a pkt
			{
//				++ pkt_dat.recvd_pkt	[ basic_ch_dat.ch ];
				++ total_no_pkts_B;
				switch ( basic_ch_dat.ch )
				{
					case 15: case 14:	empty_slts = 2;
	
					case 16: case 10: case 11: case 12: case 13: 	empty_slts = 1;

					default: empty_slts = 0;
				}

			}

		}

		recsize = recvfrom(sock, (void *) &net_dat, sizeof (struct _network_dat), MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);
		if ( 0 < recsize )
		{
			curr_seq = 	net_dat.seq;

			if ( 0 == fseq_n)
				fseq_n = curr_seq;
		}


//		if  ( 0 != memcmp ( net_dat.network_GT_afh , afh_GT_buffer, 10)  ) 
//		{
//
//			SHM_set_GH_afh (ShmPTR, collected_afh_svm);
//			memcpy ( afh_GT_buffer, net_dat.network_GT_afh, 10);
//
//		}


	}// main if statement


	if ( 1 == stop_ubertooth )
	{

		lseq_n  = curr_seq;
		printf ("fseq=%d, lseq=%d, diff=%d, tot=%d\n", fseq_n, lseq_n, lseq_n - fseq_n, total_no_pkts_B);
		stop_ubertooth = 0;
		return 1;


	}

} // main While loop


out:
	close(sock);
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
int get_adptv_pkt_rate ( struct ShMemory  *ShmPTR  )
{

	int 	i, j,  empty_slts, train_alarm = 0, local_A_indx = 0 , total_no_pkts_A = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0;

	uint8_t afh_GT_buffer [ 10 ];
	memset ( afh_GT_buffer, 1, 10);

	struct _pkt_est_dat pkt_dat;

	struct _channel_dat adptv_ch_dat;
/////////////////////////////////////////////////////////////////////////////////
///// network section
///// network section

	NETWORK_SETTING_MACRO ;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready
//	while ( STD_SPEED != ShmPTR->basic_pkt_status) 
//		;

	local_A_indx 		= SHM_get_adptv_buf_idx ( ShmPTR ) - 6 ;


while ( 1 )
{ // main While loop


	if ( local_A_indx <= (ShmPTR->bufa_pkt_idx - 6) )
	{

		SHM_read_A_buf ( ShmPTR, &adptv_ch_dat , local_A_indx);
			
		++ local_A_indx;

//		printf ("B  ptyp=%02d, ch=%u, rssi=%d, B_och=%u, B_indx=%d, ptime=%u\n", 
//			B_ptype,
//			B_ch,
//			-54 + B_rssi  ,
//			B_och,
//			B_indx,
//			B_ptime
//			);


		if ( 0 < empty_slts  )
		{	
			-- empty_slts; 
//			++ loc_dat.ch_rssi 		[ B_ch ][ get_rssi ( -54 + B_rssi ) ];
		}

		else 
		{
//			++ loc_dat.n_visits 		[ B_ch ];

			if ( -1 != adptv_ch_dat.ptype )  // check if it has a pkt
			{
//				++ pkt_dat.recvd_pkt	[ basic_ch_dat.ch ];
				++ total_no_pkts_A;
				switch ( adptv_ch_dat.ch )
				{
					case 15: case 14:	empty_slts = 2;
	
					case 16: case 10: case 11: case 12: case 13: 	empty_slts = 1;

					default: empty_slts = 0;
				}

			}

		}

		recsize = recvfrom(sock, (void *) &net_dat, sizeof (struct _network_dat), MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);
		if ( 0 < recsize )
		{
			curr_seq = 	net_dat.seq;

			if ( 0 == fseq_n)
				fseq_n = curr_seq;
		}


		if  ( 0 != memcmp ( net_dat.network_GT_afh , afh_GT_buffer, 10)  ) 
		{

			SHM_set_GH_afh (ShmPTR, afh_GT_buffer);
			memcpy ( afh_GT_buffer, net_dat.network_GT_afh, 10);

		}


	}// main if statement


	if ( 1 == stop_ubertooth )
	{

		lseq_n  = curr_seq;
		printf ("fseq=%d, lseq=%d, diff=%d, tot=%d\n", fseq_n, lseq_n, lseq_n - fseq_n, total_no_pkts_A);
		stop_ubertooth = 0;
		return 1;


	}

} // main While loop


out:
	close(sock);
	return 0;
}
/////////////////////////////////////////////////////
