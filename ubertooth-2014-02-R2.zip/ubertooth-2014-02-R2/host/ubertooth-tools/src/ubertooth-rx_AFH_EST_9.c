/*
 * Copyright 2010, 2011 Michael Ossmann
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */


#include <afh_est.h>
#include "SHM.h"
#include "SHM2.h"
#include <sys/socket.h>
#include <errno.h>

#define AJST_CH(X)((X)%79)

//	struct _network_dat net_dat_sender;\

#define ETHERNET_SETTING_SENDER_UDP\
	int bytes_sent, sock_sender = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);\
	if (-1 == sock_sender) {printf("Error Creating Socket_lan"); exit(EXIT_FAILURE);}\
	struct sockaddr_in sa_sender;\
	memset(&sa_sender, 0, sizeof sa_sender);\
	sa_sender.sin_family = AF_INET;\
	sa_sender.sin_addr.s_addr = inet_addr("192.168.10.3");\
	sa_sender.sin_port = htons(7653);

#define SEND_OVER_ETHERNET(X)\
	if (0 > sendto(sock_sender, (void *) &(X) , sizeof(X) , 0,(struct sockaddr*)&sa_sender, sizeof sa_sender) )\
	{printf("Error sending packet: %s\n", strerror(errno));exit(EXIT_FAILURE);}

#define	ETHERNET_SETTING_RCVR_UDP \
	struct _network_dat net_dat;\
	ssize_t recsize, buf_size = sizeof (struct _network_dat);\
	int  sock = socket (PF_INET, SOCK_DGRAM, IPPROTO_UDP);\
	struct sockaddr_in sa; \
	socklen_t fromlen	= sizeof(sa);\
	memset(&sa, 0, sizeof sa);\
	sa.sin_family 		= AF_INET;\
	sa.sin_addr.s_addr 	= htonl(INADDR_ANY);\
	sa.sin_port 		= htons(7654);\
 	if (-1 == bind ( sock, (struct sockaddr *) &sa, sizeof(sa)))\
	{ perror("error bind failed"); 	close(sock);	exit(EXIT_FAILURE); }


#define	RECV_NET_DAT \
	recsize = recvfrom(sock, (void *) &net_dat, buf_size, MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);\
	if ( 0 < recsize ){\
	curr_seq = net_dat.seq;\
	if ( 0 == fseq_n) fseq_n = curr_seq;}

#define PRINT_RESLT_AND_STOP \
	if ( 1 == stop_ubertooth ){\
	lseq_n  = curr_seq;\
	printf ("fseq=%d, lseq=%d, diff=%d, tot_B=%d, tot_A=%d\n", fseq_n, lseq_n, lseq_n - fseq_n, total_n_pkts_B, total_n_pkts_A);\
	stop_ubertooth = 0;\
	return 1;}

#define COUNT_ADPTV_PKTS \
	if ( 0 != SHM2_read_buf2 ( ShmPTR_A, &slt_dat_A) ) {\
		if (( 0 != slt_dat_A.ofst625_1 ) || ( 0 != slt_dat_A.ofst625_2 ))\
			++ total_n_pkts_A;\
		slt_dat_A.ofst625_1 = 0;\
		slt_dat_A.ofst625_2 = 0;\
	}// main if statement


uint8_t do_afh_est_hybrid2 	( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
uint8_t do_afh_est_pkt2 	( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
uint8_t do_afh_est_pkt3 	( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
uint8_t	do_selective_jam	( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
uint8_t do_afh_est_svm2 	( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
uint8_t do_svm_train_onetime2 	( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
uint8_t set_afh2		( struct ShMemory2 *ShmPTR_A,  struct ShMemory2 *ShmPTR_B  );
long int interval_us 		( struct timeval * start_time, struct timeval * curr_time );

uint8_t stop_ubertooth = 0; 

//////////////////////////////////
void	cleanup(int sig)
{
	sig = sig;
	stop_ubertooth = 1;
}
///////////////////////////////////
//int main ( int argc, char *argv[] )
int main (   )
{

	struct ShMemory2 *ShmPTR_A = _Get_Shmem2_ (ATTACH_SHMEM2, 'A');
	struct ShMemory2 *ShmPTR_B = _Get_Shmem2_ (ATTACH_SHMEM2, 'B');

	SHM2_init_read_indx ( ShmPTR_A, -6 );
	SHM2_init_read_indx ( ShmPTR_B, -6 );

	/* Clean up on exit. */
	signal(SIGINT,cleanup);
	signal(SIGQUIT,cleanup);
	signal(SIGTERM,cleanup);

//	do_selective_jam	(  ShmPTR_A, ShmPTR_B );

//	do_afh_est_hybrid2 	(  ShmPTR_A, ShmPTR_B );
//	do_afh_est_pkt2		(  ShmPTR_A, ShmPTR_B );
	do_afh_est_pkt3		(  ShmPTR_A, ShmPTR_B );
//	do_afh_est_svm2		(  ShmPTR_A, ShmPTR_B );
//	set_afh2 		(  ShmPTR_A, ShmPTR_B );
//	do_svm_train_onetime2	(  ShmPTR_A, ShmPTR_B );

out:
	shmdt((void *) ShmPTR_A);
	shmdt((void *) ShmPTR_B);
	return 0;
}
//////////////////////////////////////////////////////////////////////////////
uint8_t set_afh2 ( struct ShMemory2  *ShmPTR_A, struct ShMemory2  *ShmPTR_B)
{
// this function read GT_AFH from network and send it to ADPTV
// Then it calculate captured pkts in both basic and adptv
	int 	empty_slts_A = 0, empty_slts_B = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t prev_GT_afh [ 10 ] ;

	struct _slt_buf slt_dat_A;
	struct _slt_buf slt_dat_B;

/////////////////////////////////////////////////////////////////////////////////
///// network section

	ETHERNET_SETTING_RCVR_UDP ;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

//GT_afh [ 0 ] = 0x00;
//GT_afh [ 1 ] = 0x00;
//GT_afh [ 2 ] = 0x00;
//GT_afh [ 3 ] = 0xff;
//GT_afh [ 4 ] = 0xff;
//GT_afh [ 5 ] = 0xff;
//GT_afh [ 6 ] = 0xff;
//GT_afh [ 7 ] = 0xff;
//GT_afh [ 8 ] = 0xff;
//GT_afh [ 9 ] = 0xff;


while ( 1 )
{ // main While loop

	if ( 0 != compare_n_cpy ( prev_GT_afh, net_dat.network_GT_afh, 10  ) )
	{
		SHM2_set_GH_afh ( ShmPTR_A, net_dat.network_GT_afh );

		printf ("afh sent to adptv\n");

		print_afh_maps ( prev_GT_afh, net_dat.network_GT_afh );

	}// main if statement

//////////////////////////////////////////////////////////////////
	if ( 0 != SHM2_read_buf1 ( ShmPTR_B, &slt_dat_B) )
	{

		if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
		{
			++ total_n_pkts_B;


			slt_dat_B.ofst625_1 = 0;
			slt_dat_B.ofst625_2 = 0;
		}

//		print_afh_maps ( net_dat.network_GT_afh, prev_GT_afh );

	}// main if statement

//////////////////////////////////////////////////////////////////

	COUNT_ADPTV_PKTS;

	RECV_NET_DAT;
	PRINT_RESLT_AND_STOP;

} // main While loop


out1:
	close(sock);
	return 0;
}

//////////////////////////////////////////////////////////////
uint8_t do_afh_est_hybrid2 ( struct ShMemory2  *ShmPTR_A,  struct ShMemory2  *ShmPTR_B  )
{

	int 	i, empty_slts_B = 0, empty_slts_A = 0, train_alarm = 0, svm_predict_alarm = 0, pkt_predict_alarm = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t ch, collected_afh_pkt [ 10 ], collected_local_label [ 10 ] ,
		prev_local_label [ 79 ], local_label [ 79 ];

memset ( collected_local_label, 0xff, 10);
memset ( collected_afh_pkt    , 0xff, 10);

collected_local_label 	[ 9 ] = 0x7f;
collected_afh_pkt 	[ 9 ] = 0x7f;


memset ( local_label, 1, 79);

//	struct timeval currtime;
	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	_init_svm_files ( & svm_dat, &f );

	struct _pkt_est_dat pkt_dat;
memset ( pkt_dat.pkt_label, 1, 79);

	struct _slt_buf slt_dat_B;
	struct _slt_buf slt_dat_A;
/////////////////////////////////////////////////////////////////////////////////
///// network section
	ETHERNET_SETTING_RCVR_UDP;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

while ( 1 )
{ // main While loop

	if ( 0 != SHM2_read_buf2 ( ShmPTR_B, &slt_dat_B) )
	{

		++ svm_predict_alarm ; 
		++ pkt_predict_alarm ;
		++ train_alarm ;
		ch = AJST_CH(slt_dat_B.slt_ch);

		++ pkt_dat.n_visits 	[ ch ];


		if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
		{

			++ pkt_dat.recvd_pkt		[ ch ];
			++ total_n_pkts_B;

			++ svm_dat.ch_rssi 		[ ch ][ 79 ] ; // actually this means nothing
		}

		else // -1 == B_ptype
			++ svm_dat.ch_rssi 		[ ch ][ adjust_rssi2 ( slt_dat_B.slt_rssi ) ];

//////////////////////////////////////////
// 400, 800, 1600, 3200, 6400, 9600, 12800
		if ( 9600 < pkt_predict_alarm) 
//		if ( 3200 < pkt_predict_alarm) 
		{
			pkt_predict_alarm = 0 ;
			pkt_bsd_predict_func 	( & pkt_dat  );

			memcpy 			( local_label , pkt_dat.pkt_label,79);
			collect_afh 		( collected_afh_pkt, pkt_dat.pkt_label );
			memcpy 			( collected_local_label, collected_afh_pkt, 10  );

			memcpy 			( svm_dat.svm_label, local_label, 79);
			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );


		}
/////////////////////////// BEGIN SVM SECTION

		if ( ( 800 < train_alarm  ) && ( 0 ) )
//		if   ( 600 < train_alarm  ) 
		{
			train_alarm = 0;
			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );
		}
/////////////////////////////////////////
//		if (266 < svm_predict) 
//		if (800 < svm_predict_alarm) 
		if (1600 < svm_predict_alarm) 
//		if (6400 < svm_predict) 
		{
			svm_predict_alarm = 0 ;
			memcpy 			( svm_dat.svm_label, local_label, 79);
			write_SVM_data_to_file 	( & svm_dat, &f, PRDCT_DATA  );
			classify_main 		( & svm_dat, &f  );

			for ( i = 0 ; i < 79; i ++)
			{

				if ( svm_dat.ch_est_svm [ i ] > 1.2 )
//				if ( svm_dat.ch_est_svm [ i ] >= 0.99 )  
					local_label [ i ] = CH_GOOD;

				else if ( svm_dat.ch_est_svm [ i ] < -1.2 )
//				else if ( svm_dat.ch_est_svm [ i ] <= -0.99 )
					local_label [ i ] = CH_BAD;

				else 
					local_label [ i ] = pkt_dat.pkt_label [ i ];


			}

			collect_afh ( collected_local_label, local_label  );

			if ( 0 != compare_n_cpy ( prev_local_label, local_label, 79  ) )
			{
				SHM2_set_GH_afh ( ShmPTR_A, collected_local_label );
				printf ("afh sent to adptv\n");
			}

			printf ("svm predict\n");

		}


		print_afh_maps2 ( net_dat.network_GT_afh, collected_afh_pkt, collected_local_label );

//		gettimeofday( &currtime, NULL );
//
//		printf ("%ld, %ld, %d, %d, %d\n", 
//			currtime.tv_sec, currtime.tv_usec, 
//			total_n_pkts_A , total_n_pkts_B, curr_seq );

	}// main if statement
//////////////////////////////////

	COUNT_ADPTV_PKTS ;

	RECV_NET_DAT;

	PRINT_RESLT_AND_STOP ;

} // main While loop


out1:
	close(sock);
	return 0;
}
////////////////////////////////////////////////////////////////////////
uint8_t do_afh_est_pkt3 ( struct ShMemory2  *ShmPTR_A,  struct ShMemory2  *ShmPTR_B  )
{

	struct timeval currtime, starttime;
	gettimeofday( &starttime, NULL );

	long int fst_tv_sec = currtime.tv_sec;
	long int fst_tv_usec = currtime.tv_usec;
	long int duration_us = 0;

	int 	i, j, empty_slts_B = 0, empty_slts_A = 0, train_alarm = 0, svm_predict_alarm = 0, pkt_predict_alarm = 0, 
		prev_seq =0, counter = 0, curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t ch, collected_afh_pkt [ 10 ], collected_local_label [ 10 ] ,
		prev_local_label [ 79 ], local_label [ 79 ];

memset ( collected_local_label, 0xff, 10);
memset ( collected_afh_pkt    , 0xff, 10);

collected_local_label [ 9 ] &= 0x7f;
collected_afh_pkt [ 9 ] &= 0x7f;


memset ( local_label, 1, 79);

	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	_init_svm_files ( & svm_dat, &f );

	struct _pkt_est_dat pkt_dat;
memset ( pkt_dat.pkt_label, 1, 79);


	struct _slt_buf slt_dat_B;
	struct _slt_buf slt_dat_A;
/////////////////////////////////////////////////////////////////////////////////
///// network section
	ETHERNET_SETTING_RCVR_UDP;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

while ( 1 )
{ // main While loop

	if ( 0 != SHM2_read_buf2 ( ShmPTR_B, &slt_dat_B) )
	{

		++ svm_predict_alarm ; 
		++ pkt_predict_alarm ;
		++ train_alarm ;
		ch = AJST_CH(slt_dat_B.slt_ch);

		++ pkt_dat.n_visits 	[ ch ];


		if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
		{
			++ pkt_dat.recvd_pkt		[ ch ];
			++ total_n_pkts_B;

		}

//////////////////////////////////////////
// 400, 800, 1600, 3200, 6400, 9600, 12800
//		if ( 9600 < pkt_predict_alarm) 
		if ( 6400 < pkt_predict_alarm) 
		{
			pkt_predict_alarm = 0 ;
			pkt_bsd_predict_func 	( & pkt_dat  );

			collect_afh 		( collected_afh_pkt, pkt_dat.pkt_label  );

			if ( 0 != compare_n_cpy ( collected_local_label, collected_afh_pkt, 10  ) )
			{

//				collected_local_label [ 0 ] = 0x0f;
				SHM2_set_GH_afh ( ShmPTR_A, collected_local_label );
				printf ("afh sent to adptv\n");
//				collected_local_label [ 0 ] = 0x00;
			}

		}

//		collected_local_label [ 0 ] = 0x0f;
//		print_afh_maps ( net_dat.network_GT_afh, collected_afh_pkt );
//		print_afh_maps ( net_dat.network_GT_afh, collected_local_label );
//		collected_local_label [ 0 ] = 0x00;

//		gettimeofday( &currtime, NULL );
//		printf ("%ld, %ld, %d, %d, %d\n", 
//			currtime.tv_sec, currtime.tv_usec, 
//			total_n_pkts_A , total_n_pkts_B, curr_seq );

	}// main if statement
//////////////////////////////////

	COUNT_ADPTV_PKTS ;

	RECV_NET_DAT;

//	if ( prev_seq != curr_seq )
//	{
//		prev_seq = curr_seq;
//
//		gettimeofday( &currtime, NULL );
//
//		printf ("%ld, %ld, %d, %d, %d\n", 
//			currtime.tv_sec, currtime.tv_usec, 
//			total_n_pkts_A , total_n_pkts_B, curr_seq );
//
//	}

int sec = 2;
	// every one sec, print pkts and reset counters
	gettimeofday(&currtime,NULL);
	if ( ( sec * 1000000) < ( (1000000 * (currtime.tv_sec - fst_tv_sec) ) + currtime.tv_usec -fst_tv_usec) )
	{
		printf ( "%d, %d, %d, %d, %f, %f\n",  counter, curr_seq - fseq_n, total_n_pkts_A, total_n_pkts_B,
			total_n_pkts_A*1.0/(curr_seq - fseq_n), total_n_pkts_B *1.0/(curr_seq - fseq_n));
		counter		+= sec ;
//		++ counter ;
		fseq_n 		= curr_seq ;
		fst_tv_sec 	= currtime.tv_sec ;
		fst_tv_usec	= currtime.tv_usec;
		total_n_pkts_A	= 0;
		total_n_pkts_B	= 0;

//		print_afh_maps ( net_dat.network_GT_afh, collected_local_label );

	}


	PRINT_RESLT_AND_STOP ;

} // main While loop


out1:
	close(sock);
	return 0;
}
/////////////////////////////////////////////////////////////////////////////////
uint8_t do_selective_jam ( struct ShMemory2  *ShmPTR_A,  struct ShMemory2  *ShmPTR_B  )
{

	struct timeval currtime, starttime;

	gettimeofday( &starttime, NULL );

	long int fst_tv_sec = currtime.tv_sec;
	long int fst_tv_usec = currtime.tv_usec;
	long int duration_us = 0;

	int 	i, j, empty_slts_B = 0, empty_slts_A = 0, train_alarm = 0, svm_predict_alarm = 0, pkt_predict_alarm = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0,
		counter = 0, bad_flags = 0, bad_pkts [ 20 ];

	uint8_t ch, collected_afh_pkt [ 10 ], collected_local_label [ 10 ] , selective_jam = 0, 
		prev_local_label [ 79 ], local_label [ 79 ];

memset ( bad_pkts, 0, sizeof ( int )* 20 );

memset ( collected_local_label, 0xff, 10);
memset ( collected_afh_pkt    , 0xff, 10);

collected_local_label [ 9 ] &= 0x7f;
collected_afh_pkt [ 9 ] &= 0x7f;


memset ( local_label, 1, 79);

	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	_init_svm_files ( & svm_dat, &f );

	struct _pkt_est_dat pkt_dat;
memset ( pkt_dat.pkt_label, 1, 79);


	struct _slt_buf slt_dat_B;
	struct _slt_buf slt_dat_A;
/////////////////////////////////////////////////////////////////////////////////
///// network section
	ETHERNET_SETTING_RCVR_UDP;

	ETHERNET_SETTING_SENDER_UDP;

/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

while ( 1 )
{ // main While loop

	if ( 0 != SHM2_read_buf2 ( ShmPTR_B, &slt_dat_B) )
	{

		++ svm_predict_alarm ; 
		++ pkt_predict_alarm ;
		++ train_alarm ;
		ch = AJST_CH(slt_dat_B.slt_ch);

		++ pkt_dat.n_visits 	[ ch ];


		if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
		{
			++ pkt_dat.recvd_pkt		[ ch ];
			++ total_n_pkts_B;

		}
//////////////////////////////////////////

		gettimeofday(&currtime,NULL);

		duration_us = interval_us(&starttime, &currtime);

		if ( (duration_us < (10 * 1000000) )
		&&
		( 0 == selective_jam  ) )
		{
			// now we start counting bad pkts

//			selective_jam = 1;


			if ( ( 0 <= ch ) && ( ch <= 19 ) )
				++ bad_pkts [ ch ];


			// goto out1;

		//	gettimeofday(&currtime,NULL);
		//	fst_tv_sec  = currtime.tv_sec;
		//	fst_tv_usec = currtime.tv_usec;
		}
//////////////////////////////////////////
// 400, 800, 1600, 3200, 6400, 9600, 12800
		if ( 9600 < pkt_predict_alarm) 
//		if ( 6400 < pkt_predict_alarm) 
		{
			pkt_predict_alarm = 0 ;
			pkt_bsd_predict_func 	( & pkt_dat  );

			collect_afh 		( collected_afh_pkt, pkt_dat.pkt_label  );

			if ( 0 != compare_n_cpy ( collected_local_label, collected_afh_pkt, 10  ) )
			{
				SHM2_set_GH_afh ( ShmPTR_A, collected_local_label );
//				printf ("afh sent to adptv\n");
			}

		}


//		print_afh_maps ( net_dat.network_GT_afh, collected_local_label );




	}// main if statement
//////////////////////////////////
	for ( i = 0; i < 20; i ++ )
	{
		if ( 5 <= bad_pkts [ i ] )
			++ bad_flags;
	}

	if ( ( 20 == bad_flags ) && ( 0 == selective_jam  ) )
	{
		selective_jam = 1;
		net_dat.seq = 1010;
//		SEND_OVER_ETHERNET(net_dat)
		//trigger_selective_jam 
	}
//////////////////////////////////////
	COUNT_ADPTV_PKTS ;

	RECV_NET_DAT;
int sec = 2;
	// every one sec, print pkts and reset counters
	gettimeofday(&currtime,NULL);
	if ( ( sec * 1000000) < ( (1000000 * (currtime.tv_sec - fst_tv_sec) ) + currtime.tv_usec -fst_tv_usec) )
	{
		printf ( "%d, %d, %f, %f\n",  counter, curr_seq - fseq_n, 
			total_n_pkts_A*1.0/(curr_seq - fseq_n), total_n_pkts_B *1.0/(curr_seq - fseq_n));
		counter		+= sec ;
//		++ counter ;
		fseq_n 		= curr_seq ;
		fst_tv_sec 	= currtime.tv_sec ;
		fst_tv_usec	= currtime.tv_usec;
		total_n_pkts_A	= 0;
		total_n_pkts_B	= 0;

		print_afh_maps ( net_dat.network_GT_afh, collected_local_label );

	}

	PRINT_RESLT_AND_STOP ;

} // main While loop


out1:
	close(sock);
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
uint8_t do_afh_est_pkt2 ( struct ShMemory2  *ShmPTR_A,  struct ShMemory2  *ShmPTR_B  )
{

	int 	pkt_predict_alarm = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t ch, collected_afh_pkt [ 10 ], collected_local_label [ 10 ] ;

memset ( collected_local_label, 0xff, 10);
memset ( collected_afh_pkt    , 0xff, 10);

collected_local_label [ 9 ] &= 0x7f;
collected_afh_pkt [ 9 ] &= 0x7f;


	struct _pkt_est_dat pkt_dat;

memset ( pkt_dat.pkt_label, 1, 79);

	struct _slt_buf slt_dat_B;
	struct _slt_buf slt_dat_A;
/////////////////////////////////////////////////////////////////////////////////
///// network section
	ETHERNET_SETTING_RCVR_UDP;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

while ( 1 )
{ // main While loop

	if ( 0 != SHM2_read_buf2 ( ShmPTR_B, &slt_dat_B) )
	{

		++ pkt_predict_alarm ;

		ch = AJST_CH(slt_dat_B.slt_ch);

		++ pkt_dat.n_visits 	[ ch ];


		if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
		{
			++ pkt_dat.recvd_pkt		[ ch ];
			++ total_n_pkts_B;

		}

//////////////////////////////////////////
// 400, 800, 1600, 3200, 6400, 9600, 12800
//		if ( 9600 < pkt_predict_alarm) 
		if ( 9600 < pkt_predict_alarm) 
		{
			pkt_predict_alarm = 0 ;
			pkt_bsd_predict_func 	( & pkt_dat  );

			collect_afh 		( collected_afh_pkt, pkt_dat.pkt_label  );

			if ( 0 != compare_n_cpy ( collected_local_label, collected_afh_pkt, 10  ) )
			{
				SHM2_set_GH_afh ( ShmPTR_A, collected_local_label );
				printf ("afh sent to adptv\n");
			}

		}


		print_afh_maps ( net_dat.network_GT_afh, collected_afh_pkt );

	}// main if statement
//////////////////////////////////

	COUNT_ADPTV_PKTS ;

	RECV_NET_DAT;

	PRINT_RESLT_AND_STOP ;

} // main While loop


out1:
	close(sock);
	return 0;
}
/////////////////////////////////////////////////////////////////////////////////////////
uint8_t do_afh_est_svm2 ( struct ShMemory2  *ShmPTR_A,  struct ShMemory2  *ShmPTR_B  )
{

	int 	i, j, empty_slts_B = 0, empty_slts_A = 0, train_alarm = 0, svm_predict_alarm = 0, pkt_predict_alarm = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t ch, collected_afh_pkt [ 10 ], collected_local_label [ 10 ] ,
		prev_afh [ 10 ], local_label [ 79 ];

memset ( collected_local_label, 0xff, 10);
memset ( collected_afh_pkt    , 0xff, 10);
memset ( prev_afh             , 0xff, 10);

collected_local_label [ 9 ] &= 0x7f;
collected_afh_pkt [ 9 ] &= 0x7f;
prev_afh [ 9 ] &= 0x7f;

//memset ( collected_local_label, 0x7fffffffffffc0000000, 10);
memset ( &local_label[0], 1, 49);
memset ( &local_label[49], 0, 30);

	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	_init_svm_files ( & svm_dat, &f );

	struct _pkt_est_dat pkt_dat;
memset ( pkt_dat.pkt_label, 1, 79);

	struct _slt_buf slt_dat_B;
	struct _slt_buf slt_dat_A;
/////////////////////////////////////////////////////////////////////////////////
///// network section
	ETHERNET_SETTING_RCVR_UDP;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

while ( 1 )
{ // main While loop

	if ( 0 != SHM2_read_buf2 ( ShmPTR_B, &slt_dat_B) )
	{

		++ svm_predict_alarm ; 
		++ pkt_predict_alarm ;
		++ train_alarm ;
		ch = AJST_CH(slt_dat_B.slt_ch);

		++ pkt_dat.n_visits 	[ ch ];


		if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
		{

			++ pkt_dat.recvd_pkt		[ ch ];
			++ total_n_pkts_B;

			++ svm_dat.ch_rssi 		[ ch ][ 79 ] ; // actually this means nothing
		}

		else // -1 == B_ptype
			++ svm_dat.ch_rssi 		[ ch ][ adjust_rssi2 ( slt_dat_B.slt_rssi ) ];

/////////////////////////// BEGIN NETWORK SECTION
//// 400, 800, 1600, 3200, 6400, 9600, 12800
////		if ( 9600 < pkt_predict_alarm) 
//		if (( 1600 < pkt_predict_alarm) && 0 )
//		{
//			pkt_predict_alarm = 0 ;
//			pkt_bsd_predict_func 	( & pkt_dat  );
//
//			collect_afh 		( collected_afh_pkt, pkt_dat.pkt_label  );
//			compare_n_cpy 		( collected_local_label, collected_afh_pkt, 10  );
//
//			memcpy 			( local_label , pkt_dat.pkt_label,79);
//			memcpy 			( svm_dat.svm_label, pkt_dat.pkt_label, 79);
//			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
//			learn_main 		( & svm_dat, &f  );
//
//
//		}
/////////////////////////// BEGIN SVM SECTION

		if ( ( 800 < train_alarm  ) && ( 0 ) )
//		if   ( 600 < train_alarm  ) 
		{
			train_alarm = 0;
			write_SVM_data_to_file  ( & svm_dat, &f , TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );
		}
/////////////////////////////////////////
		if (800 < svm_predict_alarm) 
//		if (6400 < svm_predict_alarm) 
		{
			svm_predict_alarm = 0 ;
			memcpy 			( svm_dat.svm_label, local_label, 79);
			write_SVM_data_to_file 	( & svm_dat, &f, PRDCT_DATA  );
			classify_main 		( & svm_dat, &f  );

			for ( i = 0 ; i < 79; i ++)
			{


				if ( svm_dat.ch_est_svm [ i ] > 0.85 )
					local_label [ i ] = 1;

//				else if ( svm_dat.ch_est_svm [ i ] < -0.85 )
				else 	
					local_label [ i ] = 0;

//				else 	local_label [ i ] = pkt_dat.pkt_label [ i ];
			}

			collect_afh ( collected_local_label, local_label  );

			if ( 0 != compare_n_cpy ( prev_afh, collected_local_label, 10  ) )
			{
				SHM2_set_GH_afh ( ShmPTR_A, collected_local_label );
				printf ("afh sent to adptv\n");
			}


		}


		print_afh_maps ( net_dat.network_GT_afh, collected_local_label );

	}// main if statement
//////////////////////////////////

	COUNT_ADPTV_PKTS ;

	RECV_NET_DAT;

	PRINT_RESLT_AND_STOP ;

} // main While loop


out1:
	close(sock);
	return 0;
}
/////////////////////////////////////////////////////////////////////////////////
uint8_t do_svm_train_onetime2 ( struct ShMemory2  *ShmPTR_A,  struct ShMemory2  *ShmPTR_B  )
{

	int 	i, j, empty_slts_B = 0, empty_slts_A = 0, train_alarm = 0, svm_predict_alarm = 0, pkt_predict_alarm = 0, 
		curr_seq = 0, fseq_n= 0, lseq_n = 0, total_n_pkts_B = 0, total_n_pkts_A = 0;

	uint8_t ch, collected_afh_pkt [ 10 ], collected_local_label [ 10 ] ,
		prev_local_label [ 79 ], local_label [ 79 ];

memset ( collected_local_label, 0xff, 10);
memset ( collected_afh_pkt    , 0xff, 10);

collected_local_label [ 9 ] 	= 0x7f;
collected_afh_pkt [ 9 ] 	= 0x7f;


memset ( local_label, 1, 79);

	struct _svm_est_dat svm_dat;
	struct _svm_files f;
	_init_svm_files ( & svm_dat, &f );

	struct _pkt_est_dat pkt_dat;
memset ( pkt_dat.pkt_label, 1, 79);

	struct _slt_buf slt_dat_B;
	struct _slt_buf slt_dat_A;
/////////////////////////////////////////////////////////////////////////////////
///// network section
	ETHERNET_SETTING_RCVR_UDP;
/////////////////////////////////////////////////////////////////////////////////
	// we wait for the basic hopper to be ready

while ( 1 )
{ // main While loop

	if ( 0 != SHM2_read_buf2 ( ShmPTR_B, &slt_dat_B) )
	{

		++ svm_predict_alarm ; 
		++ pkt_predict_alarm ;
		++ train_alarm ;
		ch = AJST_CH(slt_dat_B.slt_ch);

		++ pkt_dat.n_visits 	[ ch ];


		if (( 0 != slt_dat_B.ofst625_1 ) || ( 0 != slt_dat_B.ofst625_2 ))// check if it has a pkt
		{

			++ pkt_dat.recvd_pkt		[ ch ];
			++ total_n_pkts_B;

			++ svm_dat.ch_rssi 		[ ch ][ 79 ] ; // actually this means nothing
		}

		else // -1 == B_ptype
			++ svm_dat.ch_rssi 		[ ch ][ adjust_rssi2 ( slt_dat_B.slt_rssi ) ];


/////////////////////////////////////////
		RECV_NET_DAT;

		if ( 0 != compare_n_cpy ( collected_local_label, net_dat.network_GT_afh, 10  ) )
		{
			train_alarm = 601; // so should enter the next if statment
		}

		if   ( 6400 < train_alarm  ) 
		{
			train_alarm = 0;
			local_unpack_symbols	( net_dat.network_GT_afh, svm_dat.svm_label );
			write_SVM_data_to_file  ( & svm_dat, &f, TRAIN_DATA  );
			learn_main 		( & svm_dat, &f  );
			_reset_rssi_buffers 	( & svm_dat  );
		}


/////////////////////////////////////////

		print_afh_maps ( net_dat.network_GT_afh, collected_local_label );

	}// main if statement
//////////////////////////////////

//	COUNT_ADPTV_PKTS ;
	PRINT_RESLT_AND_STOP ;

} // main While loop


out1:
	close(sock);
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////
long int interval_us ( struct timeval * start_time, struct timeval * curr_time )
{
	return 
	( (1000000 * (curr_time->tv_sec - start_time->tv_sec) ) + curr_time->tv_usec - start_time->tv_usec);

//	if ( ( ( 10 * 1000000) < ( (1000000 * (currtime.tv_sec - fst_tv_sec) ) + currtime.tv_usec -fst_tv_usec) )

}


