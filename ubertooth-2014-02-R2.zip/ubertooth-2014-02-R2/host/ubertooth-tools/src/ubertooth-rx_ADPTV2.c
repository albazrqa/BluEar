/*
 * Copyright 2010, 2011 Michael Ossmann
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#include "ubertooth.h"
#include <getopt.h>
#include <signal.h>
#include <stdlib.h>

#include <sys/time.h>
#include <sys/resource.h>

//#ifdef USE_PCAP
//#include <pcap.h>
//extern pcap_t *pcap_dumpfile;
//extern pcap_dumper_t *dumper;
//#endif // USE_PCAP

//extern FILE *dumpfile;
//extern FILE *infile;
//extern int max_ac_errors;

struct libusb_device_handle *devh = NULL;



//uint32_t address = 0x2a96ef25;
//uint32_t address = 0xdc065d23;
//uint32_t address = 0xdc06c0b3;
//uint32_t address = 0xdc0662ef;
//uint32_t address = 0x72c6653b;
//uint32_t address = 0x723397d3;
//uint32_t address = 0x72339685;
//uint32_t address = 0x72c61600;
//uint32_t address = 0xF889A175;
//uint32_t address = 0x72c66a0a;
//uint32_t address = 0x723397d3;
//uint32_t address = 0x01F3E10A;
//uint32_t address = 0xDC065D7F;
//uint32_t address = 0x72C62E7E;
//uint32_t address = 0x6AFE2C6F;
//uint32_t address = 0x72C66A2D;
//uint32_t address2 = 0xACE857F0;
//uint32_t address = 0xDC0662EF;
//#define address  0xDC065D58
const uint32_t address = 0xDC065D58;
//uint32_t address = 0x72C669FD;
//uint32_t address = 0x72C613E2;
//uint32_t address = 0x7223B0D8;
//uint32_t address = 0x72C669E2;
//uint32_t address = 0x6AFE2C6F;
//uint32_t address = 0x72C66A1C;
//uint32_t address = 0x72C66A0E;
//uint32_t address = 0x6AFE334B;
//uint32_t address = 0x6AFE2F40;
//uint32_t address2 = 0x6AFE2C6F;
//uint32_t address = 0x72C66A54;
//uint32_t address = 0xDD6C88A3;// Mouse
//uint32_t address = 0x72C61604;
#define LISTEN_ON_CH 39



static void usage()
{
	printf("ubertooth-rx - passive Bluetooth discovery/decode\n");
	printf("Usage:\n");
	printf("\t-h this help\n");
	printf("\t-i filename\n");
	printf("\t-l <LAP> to decode (6 hex), otherwise sniff all LAPs\n");
	printf("\t-u <UAP> to decode (2 hex), otherwise try to calculate (requires LAP)\n");
	printf("\t-U <0-7> set ubertooth device to use\n");
#ifdef PCAP_NOT_WORKING // commenting out because pcap support for BR is not ready and this causes confusion
#ifdef USE_PCAP
	printf("\t-c<filename> capture packets to PCAP file\n");
#endif // USE_PCAP
#endif // PCAP_NOT_WORKING
	printf("\t-d<filename> dump packets to binary file\n");
	printf("\t-e max_ac_errors (default: %d, range: 0-4)\n", max_ac_errors);
	printf("\t-s reset channel scanning\n");
	printf("\nIf an input file is not specified, an Ubertooth device is used for live capture.\n");
}

void cleanup(int sig)
{
	sig = sig;
	stop_ubertooth = 1;
}

int main(int argc, char *argv[])
{
//	setpriority(PRIO_PROCESS, 0, -20);
	char ubertooth_device = -1;

	devh = ubertooth_start(ubertooth_device = 1);

	if (devh == NULL) {
		usage();
		return 1;
		}

	cmd_set_bdaddr1( devh, address);

		/* Scan all frequencies. Same effect as
		 * ubertooth-utils -c9999. This is necessary after
		 * following a piconet. */

	/* Clean up on exit. */
	signal(SIGINT,cleanup);
	signal(SIGQUIT,cleanup);
	signal(SIGTERM,cleanup);


	struct _piconet_info_ pico_info;
	pico_info.address = address;
	init_pico_info ( &pico_info ) ;

	struct _GT_SEQ_ GT_SEQ;
	GT_SEQ.address = address;
	GT_SEQ.listen_ch = LISTEN_ON_CH;
//	init_GT_SEQ ( &GT_SEQ , 0);
	init_GT_SEQ ( &GT_SEQ , 1);

	struct ShMemory  *ShmPTR = _Get_Shmem_ (ATTACH_SHMEM, 'R');
//	assert(ShmPTR);
	struct ShMemory2 *ShmPTR2 = _Get_Shmem2_ (CREATE_SHMEM2, 'A');

	Find_TargetCLK ( ShmPTR, &GT_SEQ  );

	if ( TARGET_CLK_FOUND == ShmPTR->TargetCLK_status )
	{
		deinit_GT_SEQ ( &GT_SEQ );
		stream_rx_usb_ADPTV ( devh, ShmPTR, &pico_info, XFER_LEN, 0);
//		stream_rx_usb_ADPTV05 ( devh, ShmPTR, ShmPTR2, &pico_info, XFER_LEN, 0);
//		stream_rx_usb_ADPTV05 ( devh, ShmPTR2, &pico_info, ShmPTR->TargetCLK, XFER_LEN, 0);

//		stream_rx_usb_ADPTV3 ( devh, ShmPTR, &pico_info, XFER_LEN, 0);
//		stream_rx_usb_BASIC9 ( devh, ShmPTR, &pico_info, XFER_LEN, 0);
//		stream_rx_usb_BASIC0 ( devh, ShmPTR, &pico_info, XFER_LEN, 0);
	}

out:
	printf ("%d\n", ShmPTR->adptv_pkt_idx);
//	deinit_GT_SEQ ( &GT_SEQ );
	shmdt((void *) ShmPTR);
	shmdt((void *) ShmPTR2);
	cmd_stop(devh);
	ubertooth_stop(devh);

	return 0;
}
