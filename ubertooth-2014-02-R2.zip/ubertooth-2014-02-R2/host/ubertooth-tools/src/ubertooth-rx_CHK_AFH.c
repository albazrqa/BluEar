/*
 * Copyright 2010, 2011 Michael Ossmann
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#include "ubertooth.h"
#include <getopt.h>
#include <signal.h>
//#include <stdlib.h>

#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h> /* for close() for socket */ 
#include <stdlib.h>

//////////////////////////////////
void collect_afh ( uint8_t * afh_estimation_pkt, uint8_t * pkt_buf)
{
	int i, j, reminder, result ;
	uint8_t byte;
	for ( i = 0 ; i < 10 ; i ++ )
		pkt_buf [ i ] = 0;

	for ( i = 0 ; i < 80 ; i ++ )
	{
		result 		= i / 8 ;
		reminder 	= i % 8 ;

		if ( 1 == afh_estimation_pkt [ i ])
		{
			switch ( reminder  )
			{
				case 0:
					byte = byte ^ 0x01;
					break ;
				case 1:
					byte = byte ^ 0x02;
					break ;
				case 2:
					byte = byte ^ 0x04;
					break ;
				case 3:
					byte = byte ^ 0x08;
					break ;												
				case 4:
					byte = byte ^ 0x10;
					break ;
				case 5:
					byte = byte ^ 0x20;
					break ;												
				case 6:
					byte = byte ^ 0x40;
					break ;
				case 7:
					byte = byte ^ 0x80;
					break ;												
			}

		}

		// we finished this byte
		if ( 7 == reminder  )
		{
			pkt_buf [ result ] 	= byte;
			byte			= 0;
		}

	}
}
//////////////////////////////////
void test ();
//////////////////////////////////
void	cleanup(int sig)
{
	sig = sig;
	stop_ubertooth = 1;
}
///////////////////////////////////

int main(int argc, char *argv[])
{

	int i;
	uint8_t stop_loop ;

	/* Clean up on exit. */
	signal(SIGINT,cleanup);
	signal(SIGQUIT,cleanup);
	signal(SIGTERM,cleanup);

//	test () ;
//	goto out;
//////////////////////////////////////////////////////////////////////////
	struct ShMemory  *ShmPTR = _Get_Shmem_ (ATTACH_SHMEM);

	int  counter = 0, limit, sock = socket (PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	struct sockaddr_in sa; 
//	char rcv_buffer[1024];
	uint8_t afh_GT_buffer [ 10 ], channel_status_local [10], afh_from_estimator = 0;
	ssize_t recsize;
	socklen_t fromlen	= sizeof(sa);;
	memset(&sa, 0, sizeof sa);
	sa.sin_family 		= AF_INET;
	sa.sin_addr.s_addr 	= htonl(INADDR_ANY);
	sa.sin_port 		= htons(7654);
//	fromlen = sizeof(sa);
 
	
	for ( i = 0 ; i < 10; i ++)
		channel_status_local [ i ] = 0xff;

	channel_status_local [ 9 ] = 0x7f;


	if (-1 == bind ( sock, (struct sockaddr *) &sa, sizeof(sa)))
	{
		perror("error bind failed");
		close(sock);
		exit(EXIT_FAILURE);
	}

	for (;;) 
	{
//		recsize = recvfrom(sock, (void *) rcv_buffer, sizeof (rcv_buffer), 0, (struct sockaddr *)&sa, &fromlen);
		recsize = recvfrom(sock, (void *) afh_GT_buffer, sizeof (afh_GT_buffer), MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);
//		if (recsize < 0) 
//		{
//			fprintf(stderr, "%s\n", strerror(errno));
//			exit(EXIT_FAILURE);
//		}

//		printf("recsize: %d, %d\n ", (int) recsize, counter);
//		sleep(1);


		if ( -1 != recsize )
		{
//			printf("recsize: %d, %d\n ", (int) recsize, counter);
			for ( i = 9 ; i > -1 ; i --)
				printf ("%02x",  afh_GT_buffer 		[ i ]  );

			printf ("\n");

//			for ( i = 9 ; i > -1 ; i --)
//				printf ("%02x",  channel_status_local 	[ i ]  );

			for ( i = 0; i < 79; ++i) 
				printf ("%u:%f ", ShmPTR->channel_status_pkt [ i ], ShmPTR->afh_estimation_pkt [ i ] );
			printf ("\n");
	
			printf ("----%d-------\n", afh_from_estimator );

			afh_from_estimator = 0;

		}

		++ counter ;

		// we have a reading from AFH estimation process
		if ( 0 < ShmPTR->pkt_estimation_counter )
		{
			for ( i = 0; i < 79; ++i) 
				printf ("%u:%f ", ShmPTR->channel_status_pkt [ i ], ShmPTR->afh_estimation_pkt [ i ] );
			printf ("\n");
//			collect_afh ( ShmPTR->channel_status_pkt, channel_status_local ) ; 
			ShmPTR->pkt_estimation_counter = 0;
			afh_from_estimator = 1;
		}


		if ( 1 == stop_ubertooth )
		{
			stop_ubertooth = 0;
			break ; //goto out;
		}

	}

close(sock);

/////////////////////////////////////////////////////////////////////////
//	struct ShMemory  *ShmPTR = _Get_Shmem_ (ATTACH_SHMEM);
//
//	ShmPTR->SVM_request = SVM_READY;
//
//	stop_loop = 1 ; 
//	while ( ! stop_loop )
//	{
//		switch (  ShmPTR->SVM_request  )
//		{
//
//		case SVM_LEARN:
//
////				learn_main 	( & loc_dat  );
////				ShmPTR->SVM_request		= SVM_IDLE;
////				ShmPTR->SVM_request_responce 	= SVM_REQUEST_SATISFIED;
////
////				printf ("train ----------------------------------------\n");
//				break ;
//
//
//		case SVM_CLASSIFY:
//
////				for ( i = 0 ; i < 79 ; i++)
////					loc_dat.SVM_afh [ i ] = 0;
////
////				classify_main 	(  & loc_dat );
////
////				ShmPTR->SVM_request_responce 	= SVM_REQUEST_SATISFIED;
////
////				for ( i = 0 ; i < 79 ; i++)
////					ShmPTR->afh_svm_estimation_map [ i ] = loc_dat.SVM_afh [ i ];
////
////				printf ("classify -------------------------------------\n");
////
//				break ;
//
//		case SVM_IDLE:
////				ShmPTR->SVM_request		= SVM_READY;
//				break ;
//
//		case SVM_EXIT:
////				stop_loop = 1 ; 
//				break ;
//
//
//		}
//
//
//		if ( 1 == stop_ubertooth )
//		{
//			stop_ubertooth = 0;
//			goto out;
//		}
//
//
//	}


///////////////////////////////////////////////////



out:
//	shmdt((void *) ShmPTR);


	return 0;
}

/////////////////////////////////
void test ()
{
	int i;
	uint8_t a [ 79 ] , b [ 10 ];
	for ( i = 0 ; i < 79; i ++)
	{
		if ( 0 == (i % 8) )	a [ i ] = 1;
		else			a [ i ] = 0;
	}

	collect_afh (a , b);
	for ( i = 78 ; i > -1; i --)	printf ("%u",   a [ i ]  );		
	printf ("\n");

	for ( i = 9 ; i > -1 ; i --)	printf ("%02x",  b [ i ]  );
	printf ("\n");


}
////////////////////////////////////
