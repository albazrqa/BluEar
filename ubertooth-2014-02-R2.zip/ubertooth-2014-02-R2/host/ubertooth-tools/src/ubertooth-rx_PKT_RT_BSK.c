/*
 * Copyright 2010, 2011 Michael Ossmann
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#include "ubertooth.h"
#include <getopt.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#ifdef __cplusplus
extern "C" {
#endif

# include "svm_common.h"
# include "svm_learn.h"

#ifdef __cplusplus
}
#endif

#define TRAIN_DATA	10
#define PRDCT_DATA	20
///////////////////////////////////////////////////////////
struct _local_data {

	char		train_docfile		[200];       /* file with training examples */
	char		predict_docfile		[200];       /* file with predict examples */
	char		modelfile		[200];       /* file for resulting classifier */
	char		restartfile		[200];       /* file with initial alphas */
	char		predictionsfile		[200];


	uint8_t		afh_label		[ 79 ];

	uint8_t		channel_status_svm	[ 79 ];
	uint8_t		channel_status_pkt	[ 79 ];


	int 		n_visits		[ 79 ];
	int		missing_pkt		[ 79 ];

	int		n_pkt			[ 79 ];
	int		ch_rssi			[ 79 ] [ dB_size ]; // from -100 dBm to -20 dBm

	double		pkt_rate		[ 79 ];
	double		afh_estimation_svm	[ 79 ];
	double		afh_estimation_pkt	[ 79 ];

};
/////////////////////////////////////////////////////////////
int mem_n_cmp ( uint8_t * a, uint8_t * b, int size )
{
	int i;

	for ( i = 0 ; i < size ; i ++ )
	{
		if ( a [ i ] != b [ i ])
			return 1;
	}

	return 0;
}
///////////////////////////////////////////////////////////////
int8_t get_rssi ( int8_t rssi)
{
	int8_t local_rssi;

	// This is to restrict rssi between -100 and -20 dBm
	if ( -20 < rssi  )
		local_rssi = -20 ;
	else if ( -100 > rssi)
		local_rssi = -100 ;
	     else
		local_rssi = rssi ;

	return ((-1 * local_rssi ) - 20);
}
////////////////////////////////////////////////////////////
void	collect_afh 		( uint8_t * afh_estimation_pkt, uint8_t * out_buf_10);
int	un_collect_afh		( uint8_t * collected_afh, uint8_t * un_collected_afh);
void	write_SVM_data_to_file 	( struct _local_data *loc_dat, uint8_t * afh_label, uint8_t data_t );
int 	pkt_bsd_predict_func 	( struct _local_data *loc_dat );
double	binomial_prob 		( int n_visit, int n_pkt, double avg_pkt_rate);
void	print_afh_maps 		( uint8_t * GT_afh, uint8_t * est_afh);//, int label1, int label2);
void	print_help_learn 	( );

void	read_input_parameters_learn	( LEARN_PARM *, KERNEL_PARM *);
void	read_input_parameters_classify	( long *, long *);
//////////////////////////////////////

void _init_local_dat ( struct _local_data * loc_dat )
{

	memset ( loc_dat, 0, sizeof ( struct _local_data )  );

	strcpy ( loc_dat->train_docfile, 	"train_data");
	strcpy ( loc_dat->predict_docfile, 	"predict_data");
	strcpy ( loc_dat->modelfile, 		"svm_model");
	strcpy ( loc_dat->restartfile, 		"");  
	strcpy ( loc_dat->predictionsfile, 	"svm_predictions");

}
//////////////////////////////////
void _reset_local_buffers ( struct _local_data * loc_dat )
{
	int i , j;

	for ( i = 0; i < 79; i++)
	{
		loc_dat->n_visits 	[ i ]  = 0;
		loc_dat->n_pkt		[ i ]  = 0;

		for ( j = 0; j < dB_size; j ++ ) 
			loc_dat->ch_rssi [ i ][ j ] = 0;

	}

}
//////////////////////////////////
void	cleanup(int sig)
{
	sig = sig;
	stop_ubertooth = 1;
}
///////////////////////////////////
//int main ( int argc, char *argv[] )
int main (   )
{

	//// 1600 * 6 because we have 5 slts pkts and one pkt so on each ch we have 6 pkts 
//	const int svm_period = 800, pkt_bsd_period = 3200;

	int 		total_no_pkts = 0, fseq_n = 0, curr_seq = 0, lseq_n = 0, i, j = 0, empty_slts; //ACTIVE_SVM_PREDICT = 1, ACTIVE_PKT_PREDICT = 1, 
//			pkt_bsd_predict = 0, svm_predict = 0 , train_alarm = 0, 
	int		local_B_indx = 0, B_indx = 0 ;
//			svm_estimation_count = 0, pkt_estimation_count = 0;

	uint8_t 	B_ch, data_type, B_och;//, 
//			collected_afh_svm [ 10 ] , prev_collected_afh_svm [ 10 ],
//			collected_afh_pkt [ 10 ] , prev_collected_afh_pkt [ 10 ], svm_label [ 79 ];
	int8_t 		B_ptype, B_rssi; 
	uint32_t 	B_ptime;

	/* Clean up on exit. */
	signal(SIGINT,cleanup);
	signal(SIGQUIT,cleanup);
	signal(SIGTERM,cleanup);
/////////////////////////////////////////////////////////////////////////////////
	int  counter = 0, sock = socket (PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	struct sockaddr_in sa; 
//	char rcv_buffer[1024];
	uint8_t buf [ 14 ], afh_GT_buffer [ 10 ], prev_afh_GT [ 10 ], channel_status_local [10], afh_from_estimator = 0;
	ssize_t recsize = -1;
	socklen_t fromlen	= sizeof(sa);;
	memset(&sa, 0, sizeof sa);
	sa.sin_family 		= AF_INET;
	sa.sin_addr.s_addr 	= htonl(INADDR_ANY);
	sa.sin_port 		= htons(7654);
 
	

	if (-1 == bind ( sock, (struct sockaddr *) &sa, sizeof(sa)))
	{
		perror("error bind failed");
		close(sock);
		exit(EXIT_FAILURE);
	}
/////////////////////////////////////////////////////////////////////////////////

	struct _local_data loc_dat;
	_init_local_dat 	( & loc_dat );

	struct ShMemory  *ShmPTR = _Get_Shmem_ (ATTACH_SHMEM);

	// we wait for the basic hopper to be ready
	while ( STD_SPEED != ShmPTR->basic_pkt_status) 
		;

//	ShmPTR->svm_estimation_counter = 0;
//	ShmPTR->pkt_estimation_counter = 0;

	local_B_indx 		= ShmPTR->bufb_pkt_idx - 6 ;


	while ( 0 > recsize )
	{

//		recsize = -1;
//		recsize = recvfrom(sock, (void *) afh_GT_buffer, sizeof (afh_GT_buffer), MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);
		recsize = recvfrom(sock, (void *) buf, sizeof (buf), MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);
		fseq_n 	= buf [ 0 ]       | 
			  buf [ 1 ] << 8  | 
			  buf [ 2 ] << 16 | 
			  buf [ 3 ] << 24;
//		printf ("Start seq_n=%d\n", seq_n);
//		break;
	}

	printf ("fseq_n=%d\n", fseq_n);

while ( 1 )
{ // main While loop


	if ( local_B_indx <= (ShmPTR->bufb_pkt_idx - 6) )
	{

		B_indx 	= local_B_indx % PKT_BUF_SIZE;
		B_ch	= ShmPTR->bufb_pkt_ch   	[ B_indx  ];
		B_ptype	= ShmPTR->bufb_pkt_type 	[ B_indx  ];
		B_rssi	= ShmPTR->bufb_pkt_rssi 	[ B_indx  ];
		B_och	= ShmPTR->bufb_pkt_och		[ B_indx  ];
//		B_ptime	= ShmPTR->bufb_pkt_ptime	[ B_indx  ];
			
		++ local_B_indx;

//		printf ("B  ptyp=%02d, ch=%u, rssi=%d, B_och=%u, B_indx=%d, ptime=%u\n", 
//			B_ptype,
//			B_ch,
//			-54 + B_rssi  ,
//			B_och,
//			B_indx,
//			B_ptime
//			);


		if ( 0 < empty_slts  )
		{	
			-- empty_slts; 
//			++ loc_dat.ch_rssi 		[ B_ch ][ get_rssi ( -54 + B_rssi ) ];
		}

		else 
		{
			++ loc_dat.n_visits 		[ B_ch ];
//			++ loc_dat.ch_rssi 		[ B_ch ][ get_rssi ( -54 + B_rssi ) ];
//			++ svm_predict ; 
//			++ pkt_bsd_predict ;
//			++ train_alarm ;

			if ( -1 != B_ptype )  // check if it has a pkt
			{
				++ loc_dat.n_pkt	[ B_ch ];
				++ total_no_pkts ; 
				switch ( B_ch )
				{
					case 15: case 14:	empty_slts = 2;
	
					case 10: case 11: case 12: case 13: 	empty_slts = 1;

					default: empty_slts = 0;

				}

			}

		}

		recsize = recvfrom(sock, (void *) buf, sizeof (buf), MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);
		curr_seq = 	buf [ 0 ]       | 
			   	buf [ 1 ] << 8  | 
			   	buf [ 2 ] << 16 | 
			   	buf [ 3 ] << 24;

		if  ( 0 != strncmp ( & buf [ 4 ], afh_GT_buffer, 10)  ) ;

		strncpy ( ShmPTR->GT_afh, afh_GT_buffer, 10);
		ShmPTR->GT_afh_BUF_status = GT_AFH_FILLED ; 

		strncpy ( afh_GT_buffer, & buf [ 4 ], 10);

//		afh_GT_buffer [ 0 ] = buf [ 4 ];
//		afh_GT_buffer [ 1 ] = buf [ 5 ];
//		afh_GT_buffer [ 2 ] = buf [ 6 ];
//		afh_GT_buffer [ 3 ] = buf [ 7 ];
//		afh_GT_buffer [ 4 ] = buf [ 8 ];
//		afh_GT_buffer [ 5 ] = buf [ 9 ];
//		afh_GT_buffer [ 6 ] = buf [ 10 ];
//		afh_GT_buffer [ 7 ] = buf [ 11 ];
//		afh_GT_buffer [ 8 ] = buf [ 12 ];
//		afh_GT_buffer [ 9 ] = buf [ 13 ];

//	recsize = recvfrom(sock, (void *) afh_GT_buffer, sizeof (afh_GT_buffer), MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);
	}// main if statement


	if ( 1 == stop_ubertooth )
	{

//		while ( 0 > recsize )
//		{
//			recsize = recvfrom(sock, (void *) afh_GT_buffer, sizeof (afh_GT_buffer), MSG_DONTWAIT, (struct sockaddr *)&sa, &fromlen);
////			recsize = -1;
//			seq_n 	= afh_GT_buffer [ 0 ] | afh_GT_buffer [ 1 ] << 8 | afh_GT_buffer [ 2 ] << 16 | afh_GT_buffer [ 3 ] << 24;
////			printf ("End seq_n=%d\n", seq_n);
////			break;
//		}

//		lseq_n 	= afh_GT_buffer [ 0 ] | afh_GT_buffer [ 1 ] << 8 | afh_GT_buffer [ 2 ] << 16 | afh_GT_buffer [ 3 ] << 24;
		lseq_n  = curr_seq;
		printf ("fseq=%d, lseq=%d, diff=%d, tot=%d\n", fseq_n, lseq_n, lseq_n - fseq_n, total_no_pkts);
		stop_ubertooth = 0;
		return 1;
	}

} // main While loop


out:
	shmdt((void *) ShmPTR);
out1:
	close(sock);
	return 0;
}
/////////////////////////////////////////////////////////////////////


