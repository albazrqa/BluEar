/*
 * Copyright 2010, 2011 Michael Ossmann
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#include "ubertooth.h"
#include <getopt.h>
#include <signal.h>
#include <stdlib.h>

#include <sys/time.h>
#include <sys/resource.h>

#ifdef USE_PCAP
#include <pcap.h>
extern pcap_t *pcap_dumpfile;
extern pcap_dumper_t *dumper;
#endif // USE_PCAP

extern FILE *dumpfile;
extern FILE *infile;
extern int max_ac_errors;

struct libusb_device_handle *devh = NULL;



//uint32_t address = 0x2a96ef25;
//uint32_t address = 0xdc065d23;
//uint32_t address = 0xdc06c0b3;
//uint32_t address = 0xdc0662ef;
//uint32_t address = 0x72c6653b;
//uint32_t address = 0x723397d3;
//uint32_t address = 0x72339685;
//uint32_t address = 0x72c61600;
//uint32_t address = 0xF889A175;
//uint32_t address = 0x72c66a0a;
//uint32_t address = 0x723397d3;
//uint32_t address = 0x01F3E10A;
//uint32_t address = 0xDC065D7F;
//uint32_t address = 0x72C62E7E;
//uint32_t address = 0x6AFE2C6F;
//uint32_t address = 0x72C66A2D;
//uint32_t address2 = 0xACE857F0;
//uint32_t address = 0xDC0662EF;
//#define address  0xDC065D58
const uint32_t address = 0xDC065D58;
//uint32_t address = 0x72C669FD;
//uint32_t address = 0x72C613E2;
//uint32_t address = 0x7223B0D8;
//uint32_t address = 0x72C669E2;
//uint32_t address = 0x6AFE2C6F;
//uint32_t address = 0x72C66A1C;
//uint32_t address = 0x72C66A11;
//uint32_t address = 0x72C66A0E;
//uint32_t address = 0x6AFE334B;
//uint32_t address = 0x6AFE2F40;
//uint32_t address2 = 0x6AFE2C6F;
//uint32_t address = 0x72C66A54;
//uint32_t address = 0xDD6C88A3;// Mouse
//uint32_t address = 0x72C61604;
#define LISTEN_ON_CH 39



static void usage()
{
	printf("ubertooth-rx - passive Bluetooth discovery/decode\n");
	printf("Usage:\n");
	printf("\t-h this help\n");
	printf("\t-i filename\n");
	printf("\t-l <LAP> to decode (6 hex), otherwise sniff all LAPs\n");
	printf("\t-u <UAP> to decode (2 hex), otherwise try to calculate (requires LAP)\n");
	printf("\t-U <0-7> set ubertooth device to use\n");
#ifdef PCAP_NOT_WORKING // commenting out because pcap support for BR is not ready and this causes confusion
#ifdef USE_PCAP
	printf("\t-c<filename> capture packets to PCAP file\n");
#endif // USE_PCAP
#endif // PCAP_NOT_WORKING
	printf("\t-d<filename> dump packets to binary file\n");
	printf("\t-e max_ac_errors (default: %d, range: 0-4)\n", max_ac_errors);
	printf("\t-s reset channel scanning\n");
	printf("\nIf an input file is not specified, an Ubertooth device is used for live capture.\n");
}

void cleanup(int sig)
{
	sig = sig;
stop_ubertooth = 1;
//	if (devh) {
//		cmd_stop(devh);
//		ubertooth_stop(devh);
//	}
//	exit(0);
}

//uint32_t reverse32(uint32_t x)
//{
//    x = ((x >> 1) & 0x55555555u) | ((x & 0x55555555u) << 1);
//    x = ((x >> 2) & 0x33333333u) | ((x & 0x33333333u) << 2);
//    x = ((x >> 4) & 0x0f0f0f0fu) | ((x & 0x0f0f0f0fu) << 4);
//    x = ((x >> 8) & 0x00ff00ffu) | ((x & 0x00ff00ffu) << 8);
//    x = ((x >> 16) & 0xffffu) | ((x & 0xffffu) << 16);
//    return x;
//}

//static uint8_t reverse64(uint64_t byte)
//{
//	return 
//	(byte & 0x8000000000000000) >> 63 | 
//	(byte & 0x4000000000000000) >> 61 |
//	(byte & 0x2000000000000000) >> 59 |
//	(byte & 0x1000000000000000) >> 57 |
//	(byte & 0x0800000000000000) >> 55 |
//	(byte & 0x0400000000000000) >> 53 |
//
//	(byte & 0x80) >> 7 | 
//	(byte & 0x40) >> 5 | 
//	(byte & 0x20) >> 3 | 
//	(byte & 0x10) >> 1 | 
//	(byte & 0x08) << 1 | 
//	(byte & 0x04) << 3 | 
//	(byte & 0x02) << 5 | 
//	(byte & 0x01) << 7;
//}
int main(int argc, char *argv[])
{

//	setpriority(PRIO_PROCESS, 0, -20);
	int i;
	char ubertooth_device = -1;
	uint8_t uap, AFH_MODE;
//	uint64_t sync_new , sync3, sync4;
//	uint32_t sync1, sync2;



	devh = ubertooth_start(ubertooth_device = 0);

	if (devh == NULL) {
		usage();
		return 1;
		}

	cmd_set_bdaddr1( devh, address);

		/* Scan all frequencies. Same effect as
		 * ubertooth-utils -c9999. This is necessary after
		 * following a piconet. */

	/* Clean up on exit. */
	signal(SIGINT,cleanup);
	signal(SIGQUIT,cleanup);
	signal(SIGTERM,cleanup);


	struct _piconet_info_ pico_info;
	init_pico_info ( &pico_info, address, AFH_MODE = 0 ) ;

//	struct _GT_SEQ_ GT_SEQ;
//	init_GT_SEQ ( &GT_SEQ , address, LISTEN_CHANNEL );

//	struct ShMemory  *ShmPTR = _Get_Shmem_ (CREATE_SHMEM);
	struct ShMemory  *ShmPTR = _Get_Shmem_ (ATTACH_SHMEM);
//	assert(ShmPTR);

	if ( ONECH_PKTS_NEEDED == ShmPTR->OneCh_status ) 
	{
		ShmPTR->OneCh_status = ONECH_BUF_BUSY;
		stream_rx_usb_ONECH ( devh, ShmPTR, &pico_info, XFER_LEN, 0);
	}

	if ( TARGET_CLK_FOUND == ShmPTR->TargetCLK_status )
	{
//		local_n_pkts1 = 0;
		stream_rx_usb_BASIC ( devh, ShmPTR, &pico_info, XFER_LEN, 0);
	}


out:
	printf ("%d\n", ShmPTR->basic_pkt_idx);
	shmdt((void *) ShmPTR);
	shmctl(shmemIDD, IPC_RMID, NULL);
	cmd_stop(devh);
	ubertooth_stop(devh);
out1:
	return 0;
}


/////////////////////////////////////////////////////////

//	uint8_t unpacked [ 32 ];
//	uint8_t buf [ 4 ];
//	buf [ 0 ] = 0xf0;
//	buf [ 1 ] = 0xf0;
//	buf [ 2 ] = 0x0c;
//	buf [ 3 ] = 0x0c;

//	unpack_symbols3(buf,  unpacked);
//
//	for ( i = 0; i < 32; i++ )
//		printf ("%u", unpacked [ i ]);
//	printf("\n");
//	goto out1;


//	for ( i = 0; i < 9; i++ )
//	{
//		sync1 = 0xffffffff & pico_info.syncword;
//		sync2 = 0xffffffff & (pico_info.syncword >> 32);
//		printf ( "%x, %x, %"PRIx64 " \n", sync2, sync1 >> i, pico_info.syncword >> i );
//	}
//
//	sync1 = 0xffffffff & pico_info.syncword;
//	sync2 = 0xffffffff & (pico_info.syncword >> 32);
//
//	sync3 		= 0xffffffff & ( reverse32 ( sync1 )  );
//	sync3 		= sync3 << 32;
//
//	sync4		= 0xffffffff & ( reverse32 ( sync2 )  );
//
//	sync_new 	= sync3 | sync4 ;
//
//	printf ("-------- %"PRIx64 " \n", sync_new);
//
//	for ( i = 0; i < 9; i++ )
//	{
//		printf ( " %"PRIx64 " \n", 0x00ffffffffffffff & (sync_new >> i) );
//
//		switch ( 0x00ffffffffffffff & (sync_new >> i) )
//		{
////			case  0x1333b20606ae980d:
//			case  0x33b20606ae980d:
//							printf ("sync_shift = 0\n"); break;
////			case  0x999d90303574c06:
//			case  0x99d90303574c06:
//							printf ("sync_shift = 1\n"); break;
////			case  0x4ccec8181aba603:
//			case  0xccec8181aba603:
//							printf ("sync_shift = 2\n"); break;
////			case  0x2667640c0d5d301:
//			case  0x667640c0d5d301:
//							printf ("sync_shift = 3\n"); break;
////			case  0x1333b20606ae980:
//			case  0x333b20606ae980:
//							printf ("sync_shift = 4\n"); break;
////			case  0x999d90303574c0:
//			case  0x999d90303574c0:
//							printf ("sync_shift = 5\n"); break;
////			case  0x4ccec8181aba60:
//			case  0x4ccec8181aba60:
//							printf ("sync_shift = 6\n"); break;
////			case  0x2667640c0d5d30:
//			case  0x2667640c0d5d30:
//							printf ("sync_shift = 7\n"); break;
////			case  0x1333b20606ae98:
//			case  0x1333b20606ae98:
//							printf ("sync_shift = 8\n"); break;
//
//
//		}
//	}
//
//	goto out1;
