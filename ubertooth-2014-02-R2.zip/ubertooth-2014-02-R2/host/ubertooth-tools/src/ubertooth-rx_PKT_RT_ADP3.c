/*
 * Copyright 2010, 2011 Michael Ossmann
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#include "ubertooth.h"
#include <getopt.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#ifdef __cplusplus
extern "C" {
#endif

# include "svm_common.h"
# include "svm_learn.h"

#ifdef __cplusplus
}
#endif

//////////////////////////////////
void	cleanup(int sig)
{
	sig = sig;
	stop_ubertooth = 1;
}
///////////////////////////////////
int main (   )
{

	/* Clean up on exit. */
	signal(SIGINT,cleanup);
	signal(SIGQUIT,cleanup);
	signal(SIGTERM,cleanup);

	struct ShMemory  *ShmPTR = _Get_Shmem_ (ATTACH_SHMEM);

ShmPTR->GT_afh [ 0 ] = 0x7f;
ShmPTR->GT_afh [ 1 ] = 0xf8;
ShmPTR->GT_afh [ 2 ] = 0xff;
ShmPTR->GT_afh [ 3 ] = 0xff;
ShmPTR->GT_afh [ 4 ] = 0xff;
ShmPTR->GT_afh [ 5 ] = 0xff;
ShmPTR->GT_afh [ 6 ] = 0xff;
ShmPTR->GT_afh [ 7 ] = 0xff;
ShmPTR->GT_afh [ 8 ] = 0xff;
ShmPTR->GT_afh [ 9 ] = 0x7f;

//	ShmPTR->GT_afh_BUF_status = GT_AFH_FILLED ; 
	ShmPTR->GT_afh_BUF_status = AFH_GT_FILLED ;

out:
	shmdt((void *) ShmPTR);
out1:
//	close(sock);
	return 0;
}



