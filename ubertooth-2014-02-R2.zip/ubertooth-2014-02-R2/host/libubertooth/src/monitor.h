#ifndef _MONITOR_H_
#define _MONITOR_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <sys/time.h>
#include <assert.h>

#include "radiotap.h"

////
struct _monitor_ {
	FILE *fp;
	struct _radiotap_ radiotap;
};

////
bool monitor_init(struct _monitor_ *, char *);
void monitor_free(struct _monitor_ *);
bool monitor_rx_basic(struct _monitor_ *, struct _radiotap_ *);
bool monitor_rx(struct _monitor_ *, struct _radiotap_ *);

#endif
