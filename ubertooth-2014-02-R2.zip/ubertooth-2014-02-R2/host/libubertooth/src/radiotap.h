#ifndef _RADIOTAP_H_
#define _RADIOTAP_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <sys/time.h>
#include <assert.h>

////
struct _radiotap_ {
	__int128 clk;
	int channel, rss, ptype;
	bool has_pkt;
};

////
void radiotap_init(struct _radiotap_ *);
void radiotap_print(struct _radiotap_ *);
__int128 radiotap_clk_assign(struct _radiotap_ *, char *);

#endif
