/*
 * Copyright 2010 - 2013 Michael Ossmann, Dominic Spill, Will Code, Mike Ryan
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifndef __SHM_H__
#define __SHM_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h> /* memset */
//#include <unistd.h> /* close */
#include  <sys/ipc.h>
#include  <sys/shm.h>
#include  <inttypes.h>

// AFH GT BUFFER
#define  AFH_GT_FILLED		42
#define  AFH_GT_EMPTY		43


// TARGET_CLK
#define TARGET_CLK_N_FOUND	53
#define TARGET_CLK_FOUND	54
#define READY_FOR_ONECH_PKTS	55
#define BUF_READY_ONECH_PKTS	56


// ONE CH 
#define ONECH_BUF 		500
#define ONECH_BUF_EMPTY 	51
#define ONECH_BUF_FILLED	52
#define ONECH_PKTS_NEEDED	54
#define ONECH_BUF_BUSY		55


// SHARE MEM
#define CREATE_SHMEM 		60
#define ATTACH_SHMEM 		61

// BUFFERS
#define PKT_BUF_SIZE 		800


///////////////////////////////////////////////////////////
struct _channel_dat {
	uint8_t 	ch;
	int8_t 		ptype;
	int8_t 		rssi; 
	int		empty_slts;
	int		total_n_pkts;
	
};
///////////////////////////////////////////////////////////
struct ShMemory {

// AFH GT BUFFER
	uint8_t 	GT_afh_BUF_status; 
	uint8_t 	GT_afh 			[ 10 ]; // from real BT
	uint8_t 	GT_map 			[ 80 ]; // from real BT
// AFH PREDICTED BUFFER
//	uint8_t 	afh_ESTIMATED_status; 
//	uint8_t 	afh_ESTIMATED 		[ 10 ]; // predicted
	double		afh_estimation_svm	[ 79 ]; // predicted
	double		afh_estimation_pkt	[ 79 ]; // predicted
	uint8_t 	channel_status_svm	[ 79 ]; // predicted
	uint8_t 	channel_status_pkt	[ 79 ]; // predicted
	int		svm_estimation_counter	;
	int		pkt_estimation_counter	;
	uint8_t 	afh_remap 		[ 79 ]; // predicted
//	uint8_t		afh_remap_flag		;

////////// CLK acq
	uint8_t 	OneCh_status;
	uint8_t 	OneCh_clk6_1     	[ONECH_BUF];
	int 		OneCh_slts 	 	[ONECH_BUF];
	int  		OneCh_pkt_idx;

	uint8_t 	TargetCLK_status;
	uint32_t 	TargetCLK;

	uint32_t 	OneCh_Fst_pkt_time;
	uint32_t 	OneCh_Lst_pkt_time;

// Captured PKTS BUF
	uint8_t 	basic_pkt_status;
//	int8_t  	basic_pkt_type 		[ PKT_BUF_SIZE ];
	uint8_t 	basic_pkt_clk6_1 	[ PKT_BUF_SIZE ];
//	int 		basic_pkt_slts 		[ PKT_BUF_SIZE ];
	int 		basic_pkt_625offset	[ PKT_BUF_SIZE ];
//	uint32_t 	basic_pkt_ptime		[ PKT_BUF_SIZE ];

	int 		basic_pkt_idx;

	uint8_t 	adptv_pkt_status;
	int8_t  	adptv_pkt_type 		[ PKT_BUF_SIZE ];
	uint8_t 	adptv_pkt_clk6_1 	[ PKT_BUF_SIZE ];
//	uint16_t 	adptv_pkt_clkn 		[ PKT_BUF_SIZE ];
	int 		adptv_pkt_slts 		[ PKT_BUF_SIZE ];
	int 		adptv_pkt_625offset	[ PKT_BUF_SIZE ];
	uint32_t 	adptv_pkt_ptime		[ PKT_BUF_SIZE ];

	int 		adptv_pkt_idx;

	int8_t 		bufb_pkt_type		[ PKT_BUF_SIZE ];
	uint8_t 	bufb_pkt_ch		[ PKT_BUF_SIZE ];
	int8_t		bufb_pkt_rssi		[ PKT_BUF_SIZE ];
	uint8_t 	bufb_pkt_och		[ PKT_BUF_SIZE ];
	uint32_t	bufb_pkt_clk		[ PKT_BUF_SIZE ];
//	uint32_t	bufb_pkt_ptime		[ PKT_BUF_SIZE ];

	int		bufb_pkt_idx;


	int8_t 		bufa_pkt_type		[ PKT_BUF_SIZE ];
	uint8_t 	bufa_pkt_ch		[ PKT_BUF_SIZE ];
	int8_t		bufa_pkt_rssi		[ PKT_BUF_SIZE ];
	uint8_t 	bufa_pkt_och		[ PKT_BUF_SIZE ];
	uint32_t 	bufa_pkt_clk		[ PKT_BUF_SIZE ];
	uint32_t	bufa_pkt_ptime		[ PKT_BUF_SIZE ];

	int		bufa_pkt_idx;

//// CLK winner section
	uint32_t 	wCand ;
	uint32_t 	wCand_idx_jj ;

	int 		shmemIDD;



};

/////////////////////////////////////////////////////////////

struct ShMemory  * _Get_Shmem_ (uint8_t mode, char ID_letter);
void 	detach_Shmem ( struct ShMemory * ShmPTR );
void 	SHM_read_B_buf  	( struct ShMemory  *ShmPTR, struct _channel_dat *buf, int local_B_indx);
void 	SHM_read_A_buf  	( struct ShMemory  *ShmPTR, struct _channel_dat *buf, int local_A_indx);
void 	SHM_write_B_buf 	( struct ShMemory  *ShmPTR, struct _channel_dat *buf, int local_B_indx);
int 	SHM_get_basic_buf_idx 	( struct ShMemory  *ShmPTR ) ;
int 	SHM_get_adptv_buf_idx 	( struct ShMemory  *ShmPTR ) ;
void 	SHM_set_adptv_buf_idx  	( struct ShMemory  *ShmPTR, int idx ) ;
void 	SHM_set_basic_buf_idx 	( struct ShMemory  *ShmPTR, int idx ) ;
void 	SHM_reset_GH_afh 	( struct ShMemory  *ShmPTR );
void 	SHM_set_GH_afh 		( struct ShMemory  *ShmPTR, uint8_t * afh_10 );
void 	SHM_get_GH_afh 		( struct ShMemory  *ShmPTR, uint8_t * afh_10 );
//void SHM_read_A_buf ( struct ShMemory  *ShmPTR, struct _channel_dat *buf, int local_A_indx);
//void SHM_read_B_buf ( struct ShMemory  *ShmPTR, struct _channel_dat *buf, int local_B_indx);

#endif /* __UBERTOOTH_H__ */
