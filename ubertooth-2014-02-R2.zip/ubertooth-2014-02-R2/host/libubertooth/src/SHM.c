/*
 * Copyright 2010 - 2013 Michael Ossmann, Dominic Spill, Will Code, Mike Ryan
 *
 * This file is part of Project Ubertooth.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#include "SHM.h"

///////////////////////////////////////////////////////////////
void SHM_read_B_buf ( struct ShMemory  *ShmPTR, struct _channel_dat *buf, int local_B_indx)
{

		int B_indx 	= local_B_indx % PKT_BUF_SIZE;
		buf->ch		= ShmPTR->bufb_pkt_ch   	[ B_indx  ];
		buf->ptype	= ShmPTR->bufb_pkt_type 	[ B_indx  ];
		buf->rssi	= ShmPTR->bufb_pkt_rssi 	[ B_indx  ];

}
////////////////////////////////////////////////////////////////////
void SHM_write_B_buf ( struct ShMemory  *ShmPTR, struct _channel_dat *buf, int local_B_indx)
{

//		int B_indx = local_B_indx % PKT_BUF_SIZE;
//		ShmPTR->bufb_pkt_type		[ B_indx ]  = b_info2.ptype  ;
//		ShmPTR->bufb_pkt_ch		[ B_indx ]  = b_info2.channel2  ;
//		ShmPTR->bufb_pkt_rssi		[ B_indx ]  = b_info2.rssi  ;



}

////////////////////////////////////////////////////////////////////////////////////
void SHM_read_A_buf ( struct ShMemory  *ShmPTR, struct _channel_dat *buf, int local_A_indx)
{

		int A_indx 	= local_A_indx % PKT_BUF_SIZE;
		buf->ch		= ShmPTR->bufa_pkt_ch   	[ A_indx  ];
		buf->ptype	= ShmPTR->bufa_pkt_type 	[ A_indx  ];
		buf->rssi	= ShmPTR->bufa_pkt_rssi 	[ A_indx  ];

}

////////////////////////////////////////////////////////////////////////////////////

int SHM_get_basic_buf_idx ( struct ShMemory  *ShmPTR ) 
{ 
	return ShmPTR->bufb_pkt_idx; 
}


int SHM_get_adptv_buf_idx ( struct ShMemory  *ShmPTR ) 
{ 
	return ShmPTR->bufa_pkt_idx; 
}

void SHM_set_basic_buf_idx ( struct ShMemory  *ShmPTR, int idx ) 
{ 
	ShmPTR->bufb_pkt_idx = idx;
}


void SHM_set_adptv_buf_idx  ( struct ShMemory  *ShmPTR, int idx ) 
{ 
	ShmPTR->bufa_pkt_idx = idx;
}
////////////////////////////////////////////////////////////////////////////////
void SHM_reset_GH_afh ( struct ShMemory  *ShmPTR )
{
	memset ( ShmPTR->GT_afh, 0xff, 10 );
	ShmPTR->GT_afh_BUF_status 	= AFH_GT_EMPTY;
}

////////////////////////////////////////////////////////////////////////////////////
void SHM_set_GH_afh ( struct ShMemory  *ShmPTR, uint8_t * afh_10 )
{

	ShmPTR->GT_afh [ 0 ] = afh_10 [ 0 ];
	ShmPTR->GT_afh [ 1 ] = afh_10 [ 1 ];
	ShmPTR->GT_afh [ 2 ] = afh_10 [ 2 ];
	ShmPTR->GT_afh [ 3 ] = afh_10 [ 3 ];
	ShmPTR->GT_afh [ 4 ] = afh_10 [ 4 ];
	ShmPTR->GT_afh [ 5 ] = afh_10 [ 5 ];
	ShmPTR->GT_afh [ 6 ] = afh_10 [ 6 ];
	ShmPTR->GT_afh [ 7 ] = afh_10 [ 7 ];
	ShmPTR->GT_afh [ 8 ] = afh_10 [ 8 ];
	ShmPTR->GT_afh [ 9 ] = afh_10 [ 9 ];


	ShmPTR->GT_afh_BUF_status = AFH_GT_FILLED ;

}
////////////////////////////////////////////////////////////////////////////////////
void SHM_get_GH_afh ( struct ShMemory  *ShmPTR, uint8_t * afh_10 )
{

	afh_10 [ 0 ] = ShmPTR->GT_afh [ 0 ] ;
	afh_10 [ 1 ] = ShmPTR->GT_afh [ 1 ] ;
	afh_10 [ 2 ] = ShmPTR->GT_afh [ 2 ] ;
	afh_10 [ 3 ] = ShmPTR->GT_afh [ 3 ] ;
	afh_10 [ 4 ] = ShmPTR->GT_afh [ 4 ] ;
	afh_10 [ 5 ] = ShmPTR->GT_afh [ 5 ] ;
	afh_10 [ 6 ] = ShmPTR->GT_afh [ 6 ] ;
	afh_10 [ 7 ] = ShmPTR->GT_afh [ 7 ] ;
	afh_10 [ 8 ] = ShmPTR->GT_afh [ 8 ] ;
	afh_10 [ 9 ] = ShmPTR->GT_afh [ 9 ] ;

	ShmPTR->GT_afh_BUF_status 	= AFH_GT_EMPTY;

}

////////////////////////////////////////////////////////////////////////////////////

struct ShMemory  * _Get_Shmem_ (uint8_t mode, char ID_letter)

{
	key_t          ShmKEY;
	int            ShmID;
	struct ShMemory  *ShmPTR;

//	ShmKEY = ftok(".", 'R');
	ShmKEY = ftok(".", ID_letter);
	if ( CREATE_SHMEM == mode)
		ShmID = shmget(ShmKEY, sizeof ( struct ShMemory ), IPC_CREAT | 0666);

	else if ( ATTACH_SHMEM == mode)
		ShmID = shmget(ShmKEY, sizeof ( struct ShMemory ), 0666);

	if (ShmID < 0) { printf("*** shmget error (%d) ***\n", mode); exit(1); }
	printf("Shared memory prepared at %d ...\n", mode);

	ShmPTR = (struct ShMemory *) shmat(ShmID, NULL, 0);

	if (!ShmPTR )  { printf("*** shmat error (%d) ***\n", mode); exit(1); }
	printf("Shared memory attached at %d ...\n", mode);

	if ( CREATE_SHMEM == mode)
		memset (ShmPTR, 0, sizeof (struct ShMemory));

	ShmPTR->shmemIDD = ShmID;
	return ShmPTR;
}

///////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
void detach_Shmem ( struct ShMemory * ShmPTR )
{
	int local_shmemIDD = ShmPTR->shmemIDD;
	shmdt((void *) ShmPTR );
	shmctl(local_shmemIDD, IPC_RMID, NULL);

}
/////////////////////////////////////////////////////////////////////////////////
